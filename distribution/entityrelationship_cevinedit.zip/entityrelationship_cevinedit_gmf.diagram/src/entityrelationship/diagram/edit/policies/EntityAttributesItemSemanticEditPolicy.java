/*
 * 
 */
package entityrelationship.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyReferenceCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyReferenceRequest;

import entityrelationship.diagram.providers.EntityrelationshipElementTypes;

/**
 * @generated
 */
public class EntityAttributesItemSemanticEditPolicy extends
		EntityrelationshipBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public EntityAttributesItemSemanticEditPolicy() {
		super(EntityrelationshipElementTypes.EntityAttributes_4001);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyReferenceCommand(DestroyReferenceRequest req) {
		return getGEFWrapper(new DestroyReferenceCommand(req));
	}

}
