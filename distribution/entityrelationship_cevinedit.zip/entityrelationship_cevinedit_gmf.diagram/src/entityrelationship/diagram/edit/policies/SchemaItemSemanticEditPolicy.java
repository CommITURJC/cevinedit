/*
 * 
 */
package entityrelationship.diagram.edit.policies;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

import entityrelationship.diagram.edit.commands.CompositeAttributeCreateCommand;
import entityrelationship.diagram.edit.commands.OptionalAttributeCreateCommand;
import entityrelationship.diagram.edit.commands.PrimaryKeyAttributeCreateCommand;
import entityrelationship.diagram.edit.commands.RelationshipCreateCommand;
import entityrelationship.diagram.edit.commands.SimpleAttributeCreateCommand;
import entityrelationship.diagram.edit.commands.StrongEntityCreateCommand;
import entityrelationship.diagram.edit.commands.WeakEntityCreateCommand;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;

/**
 * @generated
 */
public class SchemaItemSemanticEditPolicy extends
		EntityrelationshipBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public SchemaItemSemanticEditPolicy() {
		super(EntityrelationshipElementTypes.Schema_1000);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (EntityrelationshipElementTypes.StrongEntity_2001 == req
				.getElementType()) {
			return getGEFWrapper(new StrongEntityCreateCommand(req));
		}
		if (EntityrelationshipElementTypes.WeakEntity_2002 == req
				.getElementType()) {
			return getGEFWrapper(new WeakEntityCreateCommand(req));
		}
		if (EntityrelationshipElementTypes.SimpleAttribute_2003 == req
				.getElementType()) {
			return getGEFWrapper(new SimpleAttributeCreateCommand(req));
		}
		if (EntityrelationshipElementTypes.CompositeAttribute_2004 == req
				.getElementType()) {
			return getGEFWrapper(new CompositeAttributeCreateCommand(req));
		}
		if (EntityrelationshipElementTypes.OptionalAttribute_2005 == req
				.getElementType()) {
			return getGEFWrapper(new OptionalAttributeCreateCommand(req));
		}
		if (EntityrelationshipElementTypes.PrimaryKeyAttribute_2006 == req
				.getElementType()) {
			return getGEFWrapper(new PrimaryKeyAttributeCreateCommand(req));
		}
		if (EntityrelationshipElementTypes.Relationship_2007 == req
				.getElementType()) {
			return getGEFWrapper(new RelationshipCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

	/**
	 * @generated
	 */
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost())
				.getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	 * @generated
	 */
	private static class DuplicateAnythingCommand extends
			DuplicateEObjectsCommand {

		/**
		 * @generated
		 */
		public DuplicateAnythingCommand(
				TransactionalEditingDomain editingDomain,
				DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req
					.getElementsToBeDuplicated(), req
					.getAllDuplicatedElementsMap());
		}

	}

}
