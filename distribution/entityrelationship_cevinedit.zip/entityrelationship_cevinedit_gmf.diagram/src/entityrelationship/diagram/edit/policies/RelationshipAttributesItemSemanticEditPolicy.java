/*
 * 
 */
package entityrelationship.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyReferenceCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyReferenceRequest;

import entityrelationship.diagram.providers.EntityrelationshipElementTypes;

/**
 * @generated
 */
public class RelationshipAttributesItemSemanticEditPolicy extends
		EntityrelationshipBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public RelationshipAttributesItemSemanticEditPolicy() {
		super(EntityrelationshipElementTypes.RelationshipAttributes_4003);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyReferenceCommand(DestroyReferenceRequest req) {
		return getGEFWrapper(new DestroyReferenceCommand(req));
	}

}
