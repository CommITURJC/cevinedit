/*
 * 
 */
package entityrelationship.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

import entityrelationship.diagram.part.EntityrelationshipVisualIDRegistry;

/**
 * @generated
 */
public class EntityrelationshipEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {

			case SchemaEditPart.VISUAL_ID:
				return new SchemaEditPart(view);

			case StrongEntityEditPart.VISUAL_ID:
				return new StrongEntityEditPart(view);

			case StrongEntityNameEditPart.VISUAL_ID:
				return new StrongEntityNameEditPart(view);

			case StrongEntityName2EditPart.VISUAL_ID:
				return new StrongEntityName2EditPart(view);

			case WeakEntityEditPart.VISUAL_ID:
				return new WeakEntityEditPart(view);

			case WeakEntityNameEditPart.VISUAL_ID:
				return new WeakEntityNameEditPart(view);

			case WeakEntityName2EditPart.VISUAL_ID:
				return new WeakEntityName2EditPart(view);

			case SimpleAttributeEditPart.VISUAL_ID:
				return new SimpleAttributeEditPart(view);

			case SimpleAttributeNameEditPart.VISUAL_ID:
				return new SimpleAttributeNameEditPart(view);

			case SimpleAttributeName2EditPart.VISUAL_ID:
				return new SimpleAttributeName2EditPart(view);

			case CompositeAttributeEditPart.VISUAL_ID:
				return new CompositeAttributeEditPart(view);

			case CompositeAttributeNameEditPart.VISUAL_ID:
				return new CompositeAttributeNameEditPart(view);

			case CompositeAttributeName2EditPart.VISUAL_ID:
				return new CompositeAttributeName2EditPart(view);

			case OptionalAttributeEditPart.VISUAL_ID:
				return new OptionalAttributeEditPart(view);

			case OptionalAttributeNameEditPart.VISUAL_ID:
				return new OptionalAttributeNameEditPart(view);

			case OptionalAttributeName2EditPart.VISUAL_ID:
				return new OptionalAttributeName2EditPart(view);

			case PrimaryKeyAttributeEditPart.VISUAL_ID:
				return new PrimaryKeyAttributeEditPart(view);

			case PrimaryKeyAttributeNameEditPart.VISUAL_ID:
				return new PrimaryKeyAttributeNameEditPart(view);

			case PrimaryKeyAttributeName2EditPart.VISUAL_ID:
				return new PrimaryKeyAttributeName2EditPart(view);

			case RelationshipEditPart.VISUAL_ID:
				return new RelationshipEditPart(view);

			case RelationshipNameEditPart.VISUAL_ID:
				return new RelationshipNameEditPart(view);

			case RelationshipName2EditPart.VISUAL_ID:
				return new RelationshipName2EditPart(view);

			case RelationshipSource_cardinality_minEditPart.VISUAL_ID:
				return new RelationshipSource_cardinality_minEditPart(view);

			case RelationshipSource_cardinality_maxEditPart.VISUAL_ID:
				return new RelationshipSource_cardinality_maxEditPart(view);

			case RelationshipTarget_cardinality_minEditPart.VISUAL_ID:
				return new RelationshipTarget_cardinality_minEditPart(view);

			case RelationshipTarget_cardinality_maxEditPart.VISUAL_ID:
				return new RelationshipTarget_cardinality_maxEditPart(view);

			case EntityAttributesEditPart.VISUAL_ID:
				return new EntityAttributesEditPart(view);

			case WrappingLabelEditPart.VISUAL_ID:
				return new WrappingLabelEditPart(view);

			case CompositeAttributeAttributesEditPart.VISUAL_ID:
				return new CompositeAttributeAttributesEditPart(view);

			case WrappingLabel2EditPart.VISUAL_ID:
				return new WrappingLabel2EditPart(view);

			case RelationshipAttributesEditPart.VISUAL_ID:
				return new RelationshipAttributesEditPart(view);

			case WrappingLabel3EditPart.VISUAL_ID:
				return new WrappingLabel3EditPart(view);

			case RelationshipSource_entityEditPart.VISUAL_ID:
				return new RelationshipSource_entityEditPart(view);

			case WrappingLabel4EditPart.VISUAL_ID:
				return new WrappingLabel4EditPart(view);

			case RelationshipTarget_entityEditPart.VISUAL_ID:
				return new RelationshipTarget_entityEditPart(view);

			case WrappingLabel5EditPart.VISUAL_ID:
				return new WrappingLabel5EditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE
				.getTextCellEditorLocator(source);
	}

}
