/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class SchemaEditHelper extends EntityrelationshipBaseEditHelper {
}
