/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class OptionalAttributeEditHelper extends
		EntityrelationshipBaseEditHelper {
}
