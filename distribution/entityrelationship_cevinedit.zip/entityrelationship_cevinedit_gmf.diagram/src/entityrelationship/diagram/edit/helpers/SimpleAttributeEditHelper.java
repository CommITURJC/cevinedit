/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class SimpleAttributeEditHelper extends EntityrelationshipBaseEditHelper {
}
