/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class CompositeAttributeEditHelper extends
		EntityrelationshipBaseEditHelper {
}
