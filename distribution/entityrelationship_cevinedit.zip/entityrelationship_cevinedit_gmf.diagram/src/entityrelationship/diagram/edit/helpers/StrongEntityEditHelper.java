/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class StrongEntityEditHelper extends EntityrelationshipBaseEditHelper {
}
