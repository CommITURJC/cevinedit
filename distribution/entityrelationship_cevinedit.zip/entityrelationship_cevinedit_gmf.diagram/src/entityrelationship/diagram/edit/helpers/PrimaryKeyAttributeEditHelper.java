/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class PrimaryKeyAttributeEditHelper extends
		EntityrelationshipBaseEditHelper {
}
