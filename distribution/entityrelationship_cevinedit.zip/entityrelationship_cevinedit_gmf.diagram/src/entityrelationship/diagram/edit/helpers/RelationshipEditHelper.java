/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class RelationshipEditHelper extends EntityrelationshipBaseEditHelper {
}
