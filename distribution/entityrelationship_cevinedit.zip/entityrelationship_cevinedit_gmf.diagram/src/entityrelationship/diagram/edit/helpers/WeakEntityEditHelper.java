/*
 * 
 */
package entityrelationship.diagram.edit.helpers;

/**
 * @generated
 */
public class WeakEntityEditHelper extends EntityrelationshipBaseEditHelper {
}
