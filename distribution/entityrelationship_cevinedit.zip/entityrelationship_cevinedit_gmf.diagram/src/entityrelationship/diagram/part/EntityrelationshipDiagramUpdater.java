/*
 * 
 */
package entityrelationship.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

import entityrelationship.Attribute;
import entityrelationship.CompositeAttribute;
import entityrelationship.Entity;
import entityrelationship.EntityrelationshipPackage;
import entityrelationship.OptionalAttribute;
import entityrelationship.PrimaryKeyAttribute;
import entityrelationship.Relationship;
import entityrelationship.Schema;
import entityrelationship.SimpleAttribute;
import entityrelationship.StrongEntity;
import entityrelationship.WeakEntity;
import entityrelationship.diagram.edit.parts.CompositeAttributeAttributesEditPart;
import entityrelationship.diagram.edit.parts.CompositeAttributeEditPart;
import entityrelationship.diagram.edit.parts.EntityAttributesEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeEditPart;
import entityrelationship.diagram.edit.parts.RelationshipAttributesEditPart;
import entityrelationship.diagram.edit.parts.RelationshipEditPart;
import entityrelationship.diagram.edit.parts.RelationshipSource_entityEditPart;
import entityrelationship.diagram.edit.parts.RelationshipTarget_entityEditPart;
import entityrelationship.diagram.edit.parts.SchemaEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeEditPart;
import entityrelationship.diagram.edit.parts.StrongEntityEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityEditPart;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;

/**
 * @generated
 */
public class EntityrelationshipDiagramUpdater {

	/**
	 * @generated
	 */
	public static boolean isShortcutOrphaned(View view) {
		return !view.isSetElement() || view.getElement() == null
				|| view.getElement().eIsProxy();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipNodeDescriptor> getSemanticChildren(
			View view) {
		switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {
		case SchemaEditPart.VISUAL_ID:
			return getSchema_1000SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipNodeDescriptor> getSchema_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		Schema modelElement = (Schema) view.getElement();
		LinkedList<EntityrelationshipNodeDescriptor> result = new LinkedList<EntityrelationshipNodeDescriptor>();
		for (Iterator<?> it = modelElement.getEntities().iterator(); it
				.hasNext();) {
			Entity childElement = (Entity) it.next();
			int visualID = EntityrelationshipVisualIDRegistry.getNodeVisualID(
					view, childElement);
			if (visualID == StrongEntityEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
			if (visualID == WeakEntityEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getAttributes().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = EntityrelationshipVisualIDRegistry.getNodeVisualID(
					view, childElement);
			if (visualID == SimpleAttributeEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
			if (visualID == CompositeAttributeEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
			if (visualID == OptionalAttributeEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
			if (visualID == PrimaryKeyAttributeEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getRelationships().iterator(); it
				.hasNext();) {
			Relationship childElement = (Relationship) it.next();
			int visualID = EntityrelationshipVisualIDRegistry.getNodeVisualID(
					view, childElement);
			if (visualID == RelationshipEditPart.VISUAL_ID) {
				result.add(new EntityrelationshipNodeDescriptor(childElement,
						visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getContainedLinks(
			View view) {
		switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {
		case SchemaEditPart.VISUAL_ID:
			return getSchema_1000ContainedLinks(view);
		case StrongEntityEditPart.VISUAL_ID:
			return getStrongEntity_2001ContainedLinks(view);
		case WeakEntityEditPart.VISUAL_ID:
			return getWeakEntity_2002ContainedLinks(view);
		case SimpleAttributeEditPart.VISUAL_ID:
			return getSimpleAttribute_2003ContainedLinks(view);
		case CompositeAttributeEditPart.VISUAL_ID:
			return getCompositeAttribute_2004ContainedLinks(view);
		case OptionalAttributeEditPart.VISUAL_ID:
			return getOptionalAttribute_2005ContainedLinks(view);
		case PrimaryKeyAttributeEditPart.VISUAL_ID:
			return getPrimaryKeyAttribute_2006ContainedLinks(view);
		case RelationshipEditPart.VISUAL_ID:
			return getRelationship_2007ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getIncomingLinks(
			View view) {
		switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {
		case StrongEntityEditPart.VISUAL_ID:
			return getStrongEntity_2001IncomingLinks(view);
		case WeakEntityEditPart.VISUAL_ID:
			return getWeakEntity_2002IncomingLinks(view);
		case SimpleAttributeEditPart.VISUAL_ID:
			return getSimpleAttribute_2003IncomingLinks(view);
		case CompositeAttributeEditPart.VISUAL_ID:
			return getCompositeAttribute_2004IncomingLinks(view);
		case OptionalAttributeEditPart.VISUAL_ID:
			return getOptionalAttribute_2005IncomingLinks(view);
		case PrimaryKeyAttributeEditPart.VISUAL_ID:
			return getPrimaryKeyAttribute_2006IncomingLinks(view);
		case RelationshipEditPart.VISUAL_ID:
			return getRelationship_2007IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getOutgoingLinks(
			View view) {
		switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {
		case StrongEntityEditPart.VISUAL_ID:
			return getStrongEntity_2001OutgoingLinks(view);
		case WeakEntityEditPart.VISUAL_ID:
			return getWeakEntity_2002OutgoingLinks(view);
		case SimpleAttributeEditPart.VISUAL_ID:
			return getSimpleAttribute_2003OutgoingLinks(view);
		case CompositeAttributeEditPart.VISUAL_ID:
			return getCompositeAttribute_2004OutgoingLinks(view);
		case OptionalAttributeEditPart.VISUAL_ID:
			return getOptionalAttribute_2005OutgoingLinks(view);
		case PrimaryKeyAttributeEditPart.VISUAL_ID:
			return getPrimaryKeyAttribute_2006OutgoingLinks(view);
		case RelationshipEditPart.VISUAL_ID:
			return getRelationship_2007OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getSchema_1000ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getStrongEntity_2001ContainedLinks(
			View view) {
		StrongEntity modelElement = (StrongEntity) view.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Entity_Attributes_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getWeakEntity_2002ContainedLinks(
			View view) {
		WeakEntity modelElement = (WeakEntity) view.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Entity_Attributes_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getSimpleAttribute_2003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getCompositeAttribute_2004ContainedLinks(
			View view) {
		CompositeAttribute modelElement = (CompositeAttribute) view
				.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_CompositeAttribute_Attributes_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getOptionalAttribute_2005ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getPrimaryKeyAttribute_2006ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getRelationship_2007ContainedLinks(
			View view) {
		Relationship modelElement = (Relationship) view.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Relationship_Attributes_4003(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Relationship_Source_entity_4004(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Relationship_Target_entity_4005(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getStrongEntity_2001IncomingLinks(
			View view) {
		StrongEntity modelElement = (StrongEntity) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Source_entity_4004(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Target_entity_4005(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getWeakEntity_2002IncomingLinks(
			View view) {
		WeakEntity modelElement = (WeakEntity) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Source_entity_4004(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Target_entity_4005(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getSimpleAttribute_2003IncomingLinks(
			View view) {
		SimpleAttribute modelElement = (SimpleAttribute) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Entity_Attributes_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_CompositeAttribute_Attributes_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Attributes_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getCompositeAttribute_2004IncomingLinks(
			View view) {
		CompositeAttribute modelElement = (CompositeAttribute) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Entity_Attributes_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Attributes_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getOptionalAttribute_2005IncomingLinks(
			View view) {
		OptionalAttribute modelElement = (OptionalAttribute) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Entity_Attributes_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Attributes_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getPrimaryKeyAttribute_2006IncomingLinks(
			View view) {
		PrimaryKeyAttribute modelElement = (PrimaryKeyAttribute) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Entity_Attributes_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Relationship_Attributes_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getRelationship_2007IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getStrongEntity_2001OutgoingLinks(
			View view) {
		StrongEntity modelElement = (StrongEntity) view.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Entity_Attributes_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getWeakEntity_2002OutgoingLinks(
			View view) {
		WeakEntity modelElement = (WeakEntity) view.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Entity_Attributes_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getSimpleAttribute_2003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getCompositeAttribute_2004OutgoingLinks(
			View view) {
		CompositeAttribute modelElement = (CompositeAttribute) view
				.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_CompositeAttribute_Attributes_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getOptionalAttribute_2005OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getPrimaryKeyAttribute_2006OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<EntityrelationshipLinkDescriptor> getRelationship_2007OutgoingLinks(
			View view) {
		Relationship modelElement = (Relationship) view.getElement();
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Relationship_Attributes_4003(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Relationship_Source_entity_4004(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Relationship_Target_entity_4005(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getIncomingFeatureModelFacetLinks_Entity_Attributes_4001(
			Attribute target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == EntityrelationshipPackage.eINSTANCE
					.getEntity_Attributes()) {
				result.add(new EntityrelationshipLinkDescriptor(setting
						.getEObject(), target,
						EntityrelationshipElementTypes.EntityAttributes_4001,
						EntityAttributesEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getIncomingFeatureModelFacetLinks_CompositeAttribute_Attributes_4002(
			SimpleAttribute target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == EntityrelationshipPackage.eINSTANCE
					.getCompositeAttribute_Attributes()) {
				result.add(new EntityrelationshipLinkDescriptor(
						setting.getEObject(),
						target,
						EntityrelationshipElementTypes.CompositeAttributeAttributes_4002,
						CompositeAttributeAttributesEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getIncomingFeatureModelFacetLinks_Relationship_Attributes_4003(
			Attribute target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == EntityrelationshipPackage.eINSTANCE
					.getRelationship_Attributes()) {
				result.add(new EntityrelationshipLinkDescriptor(
						setting.getEObject(),
						target,
						EntityrelationshipElementTypes.RelationshipAttributes_4003,
						RelationshipAttributesEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getIncomingFeatureModelFacetLinks_Relationship_Source_entity_4004(
			Entity target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == EntityrelationshipPackage.eINSTANCE
					.getRelationship_Source_entity()) {
				result.add(new EntityrelationshipLinkDescriptor(
						setting.getEObject(),
						target,
						EntityrelationshipElementTypes.RelationshipSource_entity_4004,
						RelationshipSource_entityEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getIncomingFeatureModelFacetLinks_Relationship_Target_entity_4005(
			Entity target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == EntityrelationshipPackage.eINSTANCE
					.getRelationship_Target_entity()) {
				result.add(new EntityrelationshipLinkDescriptor(
						setting.getEObject(),
						target,
						EntityrelationshipElementTypes.RelationshipTarget_entity_4005,
						RelationshipTarget_entityEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getOutgoingFeatureModelFacetLinks_Entity_Attributes_4001(
			Entity source) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		for (Iterator<?> destinations = source.getAttributes().iterator(); destinations
				.hasNext();) {
			Attribute destination = (Attribute) destinations.next();
			result.add(new EntityrelationshipLinkDescriptor(source,
					destination,
					EntityrelationshipElementTypes.EntityAttributes_4001,
					EntityAttributesEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getOutgoingFeatureModelFacetLinks_CompositeAttribute_Attributes_4002(
			CompositeAttribute source) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		for (Iterator<?> destinations = source.getAttributes().iterator(); destinations
				.hasNext();) {
			SimpleAttribute destination = (SimpleAttribute) destinations.next();
			result.add(new EntityrelationshipLinkDescriptor(
					source,
					destination,
					EntityrelationshipElementTypes.CompositeAttributeAttributes_4002,
					CompositeAttributeAttributesEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getOutgoingFeatureModelFacetLinks_Relationship_Attributes_4003(
			Relationship source) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		for (Iterator<?> destinations = source.getAttributes().iterator(); destinations
				.hasNext();) {
			Attribute destination = (Attribute) destinations.next();
			result.add(new EntityrelationshipLinkDescriptor(source,
					destination,
					EntityrelationshipElementTypes.RelationshipAttributes_4003,
					RelationshipAttributesEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getOutgoingFeatureModelFacetLinks_Relationship_Source_entity_4004(
			Relationship source) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Entity destination = source.getSource_entity();
		if (destination == null) {
			return result;
		}
		result.add(new EntityrelationshipLinkDescriptor(source, destination,
				EntityrelationshipElementTypes.RelationshipSource_entity_4004,
				RelationshipSource_entityEditPart.VISUAL_ID));
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<EntityrelationshipLinkDescriptor> getOutgoingFeatureModelFacetLinks_Relationship_Target_entity_4005(
			Relationship source) {
		LinkedList<EntityrelationshipLinkDescriptor> result = new LinkedList<EntityrelationshipLinkDescriptor>();
		Entity destination = source.getTarget_entity();
		if (destination == null) {
			return result;
		}
		result.add(new EntityrelationshipLinkDescriptor(source, destination,
				EntityrelationshipElementTypes.RelationshipTarget_entity_4005,
				RelationshipTarget_entityEditPart.VISUAL_ID));
		return result;
	}

	/**
	 * @generated
	 */
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		 * @generated
		 */
		@Override
		public List<EntityrelationshipNodeDescriptor> getSemanticChildren(
				View view) {
			return EntityrelationshipDiagramUpdater.getSemanticChildren(view);
		}

		/**
		 * @generated
		 */
		@Override
		public List<EntityrelationshipLinkDescriptor> getContainedLinks(
				View view) {
			return EntityrelationshipDiagramUpdater.getContainedLinks(view);
		}

		/**
		 * @generated
		 */
		@Override
		public List<EntityrelationshipLinkDescriptor> getIncomingLinks(View view) {
			return EntityrelationshipDiagramUpdater.getIncomingLinks(view);
		}

		/**
		 * @generated
		 */
		@Override
		public List<EntityrelationshipLinkDescriptor> getOutgoingLinks(View view) {
			return EntityrelationshipDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
