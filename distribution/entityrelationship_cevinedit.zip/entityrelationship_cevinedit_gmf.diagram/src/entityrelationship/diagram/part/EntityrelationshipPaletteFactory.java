/*
 * 
 */
package entityrelationship.diagram.part;

import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

import entityrelationship.diagram.providers.EntityrelationshipElementTypes;

/**
 * @generated
 */
public class EntityrelationshipPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	 * Creates "Objects" palette tool group
	 * @generated
	 */
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createCompositeAttribute1CreationTool());
		paletteContainer.add(createOptionalAttribute2CreationTool());
		paletteContainer.add(createPrimaryKeyAttribute3CreationTool());
		paletteContainer.add(createRelationship4CreationTool());
		paletteContainer.add(createSimpleAttribute5CreationTool());
		paletteContainer.add(createStrongEntity6CreationTool());
		paletteContainer.add(createWeakEntity7CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Connections" palette tool group
	 * @generated
	 */
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createAttributes1CreationTool());
		paletteContainer.add(createAttributes2CreationTool());
		paletteContainer.add(createAttributes3CreationTool());
		paletteContainer.add(createSource_entity4CreationTool());
		paletteContainer.add(createTarget_entity5CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCompositeAttribute1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.CompositeAttribute1CreationTool_title,
				Messages.CompositeAttribute1CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.CompositeAttribute_2004));
		entry.setId("createCompositeAttribute1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.CompositeAttribute_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createOptionalAttribute2CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.OptionalAttribute2CreationTool_title,
				Messages.OptionalAttribute2CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.OptionalAttribute_2005));
		entry.setId("createOptionalAttribute2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.OptionalAttribute_2005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPrimaryKeyAttribute3CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.PrimaryKeyAttribute3CreationTool_title,
				Messages.PrimaryKeyAttribute3CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.PrimaryKeyAttribute_2006));
		entry.setId("createPrimaryKeyAttribute3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.PrimaryKeyAttribute_2006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createRelationship4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.Relationship4CreationTool_title,
				Messages.Relationship4CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.Relationship_2007));
		entry.setId("createRelationship4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.Relationship_2007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSimpleAttribute5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.SimpleAttribute5CreationTool_title,
				Messages.SimpleAttribute5CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.SimpleAttribute_2003));
		entry.setId("createSimpleAttribute5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.SimpleAttribute_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createStrongEntity6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.StrongEntity6CreationTool_title,
				Messages.StrongEntity6CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.StrongEntity_2001));
		entry.setId("createStrongEntity6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.StrongEntity_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createWeakEntity7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				Messages.WeakEntity7CreationTool_title,
				Messages.WeakEntity7CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.WeakEntity_2002));
		entry.setId("createWeakEntity7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.WeakEntity_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createAttributes1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				Messages.Attributes1CreationTool_title,
				Messages.Attributes1CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.EntityAttributes_4001));
		entry.setId("createAttributes1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.EntityAttributes_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createAttributes2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				Messages.Attributes2CreationTool_title,
				Messages.Attributes2CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.CompositeAttributeAttributes_4002));
		entry.setId("createAttributes2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.CompositeAttributeAttributes_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createAttributes3CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				Messages.Attributes3CreationTool_title,
				Messages.Attributes3CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.RelationshipAttributes_4003));
		entry.setId("createAttributes3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.RelationshipAttributes_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSource_entity4CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				Messages.Source_entity4CreationTool_title,
				Messages.Source_entity4CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.RelationshipSource_entity_4004));
		entry.setId("createSource_entity4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.RelationshipSource_entity_4004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTarget_entity5CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				Messages.Target_entity5CreationTool_title,
				Messages.Target_entity5CreationTool_desc,
				Collections
						.singletonList(EntityrelationshipElementTypes.RelationshipTarget_entity_4005));
		entry.setId("createTarget_entity5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(EntityrelationshipElementTypes
				.getImageDescriptor(EntityrelationshipElementTypes.RelationshipTarget_entity_4005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}
