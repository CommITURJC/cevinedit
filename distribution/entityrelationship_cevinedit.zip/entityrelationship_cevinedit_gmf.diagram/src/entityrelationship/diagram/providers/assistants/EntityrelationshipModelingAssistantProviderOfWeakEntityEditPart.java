/*
 * 
 */
package entityrelationship.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

import entityrelationship.diagram.edit.parts.CompositeAttributeEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityEditPart;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;
import entityrelationship.diagram.providers.EntityrelationshipModelingAssistantProvider;

/**
 * @generated
 */
public class EntityrelationshipModelingAssistantProviderOfWeakEntityEditPart
		extends EntityrelationshipModelingAssistantProvider {

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((WeakEntityEditPart) sourceEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnSource(WeakEntityEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source,
			IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget(
				(WeakEntityEditPart) sourceEditPart, targetEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnSourceAndTarget(
			WeakEntityEditPart source, IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof SimpleAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		}
		if (targetEditPart instanceof CompositeAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		}
		if (targetEditPart instanceof OptionalAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		}
		if (targetEditPart instanceof PrimaryKeyAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		}
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForTarget(IAdaptable source,
			IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((WeakEntityEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetTypesForTarget(WeakEntityEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == EntityrelationshipElementTypes.EntityAttributes_4001) {
			types.add(EntityrelationshipElementTypes.SimpleAttribute_2003);
			types.add(EntityrelationshipElementTypes.CompositeAttribute_2004);
			types.add(EntityrelationshipElementTypes.OptionalAttribute_2005);
			types.add(EntityrelationshipElementTypes.PrimaryKeyAttribute_2006);
		}
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((WeakEntityEditPart) targetEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnTarget(WeakEntityEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(EntityrelationshipElementTypes.RelationshipSource_entity_4004);
		types.add(EntityrelationshipElementTypes.RelationshipTarget_entity_4005);
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForSource(IAdaptable target,
			IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((WeakEntityEditPart) targetEditPart,
				relationshipType);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetTypesForSource(WeakEntityEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == EntityrelationshipElementTypes.RelationshipSource_entity_4004) {
			types.add(EntityrelationshipElementTypes.Relationship_2007);
		} else if (relationshipType == EntityrelationshipElementTypes.RelationshipTarget_entity_4005) {
			types.add(EntityrelationshipElementTypes.Relationship_2007);
		}
		return types;
	}

}
