/*
 * 
 */
package entityrelationship.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeEditPart;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;
import entityrelationship.diagram.providers.EntityrelationshipModelingAssistantProvider;

/**
 * @generated
 */
public class EntityrelationshipModelingAssistantProviderOfPrimaryKeyAttributeEditPart
		extends EntityrelationshipModelingAssistantProvider {

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((PrimaryKeyAttributeEditPart) targetEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnTarget(
			PrimaryKeyAttributeEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForSource(IAdaptable target,
			IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource(
				(PrimaryKeyAttributeEditPart) targetEditPart, relationshipType);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetTypesForSource(
			PrimaryKeyAttributeEditPart target, IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == EntityrelationshipElementTypes.EntityAttributes_4001) {
			types.add(EntityrelationshipElementTypes.StrongEntity_2001);
			types.add(EntityrelationshipElementTypes.WeakEntity_2002);
		} else if (relationshipType == EntityrelationshipElementTypes.RelationshipAttributes_4003) {
			types.add(EntityrelationshipElementTypes.Relationship_2007);
		}
		return types;
	}

}
