/*
 * 
 */
package entityrelationship.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

import entityrelationship.diagram.edit.parts.CompositeAttributeEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeEditPart;
import entityrelationship.diagram.edit.parts.RelationshipEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeEditPart;
import entityrelationship.diagram.edit.parts.StrongEntityEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityEditPart;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;
import entityrelationship.diagram.providers.EntityrelationshipModelingAssistantProvider;

/**
 * @generated
 */
public class EntityrelationshipModelingAssistantProviderOfRelationshipEditPart
		extends EntityrelationshipModelingAssistantProvider {

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((RelationshipEditPart) sourceEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnSource(RelationshipEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(3);
		types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		types.add(EntityrelationshipElementTypes.RelationshipSource_entity_4004);
		types.add(EntityrelationshipElementTypes.RelationshipTarget_entity_4005);
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source,
			IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget(
				(RelationshipEditPart) sourceEditPart, targetEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnSourceAndTarget(
			RelationshipEditPart source, IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof SimpleAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		}
		if (targetEditPart instanceof CompositeAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		}
		if (targetEditPart instanceof OptionalAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		}
		if (targetEditPart instanceof PrimaryKeyAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		}
		if (targetEditPart instanceof StrongEntityEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipSource_entity_4004);
		}
		if (targetEditPart instanceof WeakEntityEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipSource_entity_4004);
		}
		if (targetEditPart instanceof StrongEntityEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipTarget_entity_4005);
		}
		if (targetEditPart instanceof WeakEntityEditPart) {
			types.add(EntityrelationshipElementTypes.RelationshipTarget_entity_4005);
		}
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForTarget(IAdaptable source,
			IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((RelationshipEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetTypesForTarget(RelationshipEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == EntityrelationshipElementTypes.RelationshipAttributes_4003) {
			types.add(EntityrelationshipElementTypes.SimpleAttribute_2003);
			types.add(EntityrelationshipElementTypes.CompositeAttribute_2004);
			types.add(EntityrelationshipElementTypes.OptionalAttribute_2005);
			types.add(EntityrelationshipElementTypes.PrimaryKeyAttribute_2006);
		} else if (relationshipType == EntityrelationshipElementTypes.RelationshipSource_entity_4004) {
			types.add(EntityrelationshipElementTypes.StrongEntity_2001);
			types.add(EntityrelationshipElementTypes.WeakEntity_2002);
		} else if (relationshipType == EntityrelationshipElementTypes.RelationshipTarget_entity_4005) {
			types.add(EntityrelationshipElementTypes.StrongEntity_2001);
			types.add(EntityrelationshipElementTypes.WeakEntity_2002);
		}
		return types;
	}

}
