/*
 * 
 */
package entityrelationship.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

import entityrelationship.diagram.providers.EntityrelationshipElementTypes;
import entityrelationship.diagram.providers.EntityrelationshipModelingAssistantProvider;

/**
 * @generated
 */
public class EntityrelationshipModelingAssistantProviderOfSchemaEditPart extends
		EntityrelationshipModelingAssistantProvider {

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(7);
		types.add(EntityrelationshipElementTypes.StrongEntity_2001);
		types.add(EntityrelationshipElementTypes.WeakEntity_2002);
		types.add(EntityrelationshipElementTypes.SimpleAttribute_2003);
		types.add(EntityrelationshipElementTypes.CompositeAttribute_2004);
		types.add(EntityrelationshipElementTypes.OptionalAttribute_2005);
		types.add(EntityrelationshipElementTypes.PrimaryKeyAttribute_2006);
		types.add(EntityrelationshipElementTypes.Relationship_2007);
		return types;
	}

}
