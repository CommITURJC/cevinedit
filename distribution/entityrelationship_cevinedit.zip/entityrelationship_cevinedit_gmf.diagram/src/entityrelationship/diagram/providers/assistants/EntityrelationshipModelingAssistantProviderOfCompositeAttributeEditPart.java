/*
 * 
 */
package entityrelationship.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

import entityrelationship.diagram.edit.parts.CompositeAttributeEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeEditPart;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;
import entityrelationship.diagram.providers.EntityrelationshipModelingAssistantProvider;

/**
 * @generated
 */
public class EntityrelationshipModelingAssistantProviderOfCompositeAttributeEditPart
		extends EntityrelationshipModelingAssistantProvider {

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((CompositeAttributeEditPart) sourceEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnSource(
			CompositeAttributeEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(EntityrelationshipElementTypes.CompositeAttributeAttributes_4002);
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source,
			IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget(
				(CompositeAttributeEditPart) sourceEditPart, targetEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnSourceAndTarget(
			CompositeAttributeEditPart source, IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof SimpleAttributeEditPart) {
			types.add(EntityrelationshipElementTypes.CompositeAttributeAttributes_4002);
		}
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForTarget(IAdaptable source,
			IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((CompositeAttributeEditPart) sourceEditPart,
				relationshipType);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetTypesForTarget(
			CompositeAttributeEditPart source, IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == EntityrelationshipElementTypes.CompositeAttributeAttributes_4002) {
			types.add(EntityrelationshipElementTypes.SimpleAttribute_2003);
		}
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((CompositeAttributeEditPart) targetEditPart);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetRelTypesOnTarget(
			CompositeAttributeEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(EntityrelationshipElementTypes.EntityAttributes_4001);
		types.add(EntityrelationshipElementTypes.RelationshipAttributes_4003);
		return types;
	}

	/**
	 * @generated
	 */
	@Override
	public List<IElementType> getTypesForSource(IAdaptable target,
			IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((CompositeAttributeEditPart) targetEditPart,
				relationshipType);
	}

	/**
	 * @generated
	 */
	public List<IElementType> doGetTypesForSource(
			CompositeAttributeEditPart target, IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == EntityrelationshipElementTypes.EntityAttributes_4001) {
			types.add(EntityrelationshipElementTypes.StrongEntity_2001);
			types.add(EntityrelationshipElementTypes.WeakEntity_2002);
		} else if (relationshipType == EntityrelationshipElementTypes.RelationshipAttributes_4003) {
			types.add(EntityrelationshipElementTypes.Relationship_2007);
		}
		return types;
	}

}
