/*
 * 
 */
package entityrelationship.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

import entityrelationship.EntityrelationshipPackage;
import entityrelationship.diagram.edit.parts.CompositeAttributeName2EditPart;
import entityrelationship.diagram.edit.parts.CompositeAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeName2EditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeName2EditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.RelationshipName2EditPart;
import entityrelationship.diagram.edit.parts.RelationshipNameEditPart;
import entityrelationship.diagram.edit.parts.RelationshipSource_cardinality_maxEditPart;
import entityrelationship.diagram.edit.parts.RelationshipSource_cardinality_minEditPart;
import entityrelationship.diagram.edit.parts.RelationshipTarget_cardinality_maxEditPart;
import entityrelationship.diagram.edit.parts.RelationshipTarget_cardinality_minEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeName2EditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.StrongEntityName2EditPart;
import entityrelationship.diagram.edit.parts.StrongEntityNameEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityName2EditPart;
import entityrelationship.diagram.edit.parts.WeakEntityNameEditPart;
import entityrelationship.diagram.parsers.MessageFormatParser;
import entityrelationship.diagram.part.EntityrelationshipVisualIDRegistry;

/**
 * @generated
 */
public class EntityrelationshipParserProvider extends AbstractProvider
		implements IParserProvider {

	/**
	 * @generated
	 */
	private IParser strongEntityName_5001Parser;

	/**
	 * @generated
	 */
	private IParser getStrongEntityName_5001Parser() {
		if (strongEntityName_5001Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getEntity_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			strongEntityName_5001Parser = parser;
		}
		return strongEntityName_5001Parser;
	}

	/**
	 * @generated
	 */
	private IParser strongEntityName_5002Parser;

	/**
	 * @generated
	 */
	private IParser getStrongEntityName_5002Parser() {
		if (strongEntityName_5002Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getEntity_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			strongEntityName_5002Parser = parser;
		}
		return strongEntityName_5002Parser;
	}

	/**
	 * @generated
	 */
	private IParser weakEntityName_5003Parser;

	/**
	 * @generated
	 */
	private IParser getWeakEntityName_5003Parser() {
		if (weakEntityName_5003Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getEntity_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			weakEntityName_5003Parser = parser;
		}
		return weakEntityName_5003Parser;
	}

	/**
	 * @generated
	 */
	private IParser weakEntityName_5004Parser;

	/**
	 * @generated
	 */
	private IParser getWeakEntityName_5004Parser() {
		if (weakEntityName_5004Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getEntity_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			weakEntityName_5004Parser = parser;
		}
		return weakEntityName_5004Parser;
	}

	/**
	 * @generated
	 */
	private IParser simpleAttributeName_5005Parser;

	/**
	 * @generated
	 */
	private IParser getSimpleAttributeName_5005Parser() {
		if (simpleAttributeName_5005Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			simpleAttributeName_5005Parser = parser;
		}
		return simpleAttributeName_5005Parser;
	}

	/**
	 * @generated
	 */
	private IParser simpleAttributeName_5006Parser;

	/**
	 * @generated
	 */
	private IParser getSimpleAttributeName_5006Parser() {
		if (simpleAttributeName_5006Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			simpleAttributeName_5006Parser = parser;
		}
		return simpleAttributeName_5006Parser;
	}

	/**
	 * @generated
	 */
	private IParser compositeAttributeName_5007Parser;

	/**
	 * @generated
	 */
	private IParser getCompositeAttributeName_5007Parser() {
		if (compositeAttributeName_5007Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			compositeAttributeName_5007Parser = parser;
		}
		return compositeAttributeName_5007Parser;
	}

	/**
	 * @generated
	 */
	private IParser compositeAttributeName_5008Parser;

	/**
	 * @generated
	 */
	private IParser getCompositeAttributeName_5008Parser() {
		if (compositeAttributeName_5008Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			compositeAttributeName_5008Parser = parser;
		}
		return compositeAttributeName_5008Parser;
	}

	/**
	 * @generated
	 */
	private IParser optionalAttributeName_5009Parser;

	/**
	 * @generated
	 */
	private IParser getOptionalAttributeName_5009Parser() {
		if (optionalAttributeName_5009Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			optionalAttributeName_5009Parser = parser;
		}
		return optionalAttributeName_5009Parser;
	}

	/**
	 * @generated
	 */
	private IParser optionalAttributeName_5010Parser;

	/**
	 * @generated
	 */
	private IParser getOptionalAttributeName_5010Parser() {
		if (optionalAttributeName_5010Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			optionalAttributeName_5010Parser = parser;
		}
		return optionalAttributeName_5010Parser;
	}

	/**
	 * @generated
	 */
	private IParser primaryKeyAttributeName_5011Parser;

	/**
	 * @generated
	 */
	private IParser getPrimaryKeyAttributeName_5011Parser() {
		if (primaryKeyAttributeName_5011Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			primaryKeyAttributeName_5011Parser = parser;
		}
		return primaryKeyAttributeName_5011Parser;
	}

	/**
	 * @generated
	 */
	private IParser primaryKeyAttributeName_5012Parser;

	/**
	 * @generated
	 */
	private IParser getPrimaryKeyAttributeName_5012Parser() {
		if (primaryKeyAttributeName_5012Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getAttribute_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			primaryKeyAttributeName_5012Parser = parser;
		}
		return primaryKeyAttributeName_5012Parser;
	}

	/**
	 * @generated
	 */
	private IParser relationshipName_5013Parser;

	/**
	 * @generated
	 */
	private IParser getRelationshipName_5013Parser() {
		if (relationshipName_5013Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getRelationship_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			relationshipName_5013Parser = parser;
		}
		return relationshipName_5013Parser;
	}

	/**
	 * @generated
	 */
	private IParser relationshipName_5014Parser;

	/**
	 * @generated
	 */
	private IParser getRelationshipName_5014Parser() {
		if (relationshipName_5014Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getRelationship_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			relationshipName_5014Parser = parser;
		}
		return relationshipName_5014Parser;
	}

	/**
	 * @generated
	 */
	private IParser relationshipSource_cardinality_min_5015Parser;

	/**
	 * @generated
	 */
	private IParser getRelationshipSource_cardinality_min_5015Parser() {
		if (relationshipSource_cardinality_min_5015Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getRelationship_Source_cardinality_min() };
			MessageFormatParser parser = new MessageFormatParser(features);
			relationshipSource_cardinality_min_5015Parser = parser;
		}
		return relationshipSource_cardinality_min_5015Parser;
	}

	/**
	 * @generated
	 */
	private IParser relationshipSource_cardinality_max_5016Parser;

	/**
	 * @generated
	 */
	private IParser getRelationshipSource_cardinality_max_5016Parser() {
		if (relationshipSource_cardinality_max_5016Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getRelationship_Source_cardinality_max() };
			MessageFormatParser parser = new MessageFormatParser(features);
			relationshipSource_cardinality_max_5016Parser = parser;
		}
		return relationshipSource_cardinality_max_5016Parser;
	}

	/**
	 * @generated
	 */
	private IParser relationshipTarget_cardinality_min_5017Parser;

	/**
	 * @generated
	 */
	private IParser getRelationshipTarget_cardinality_min_5017Parser() {
		if (relationshipTarget_cardinality_min_5017Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getRelationship_Target_cardinality_min() };
			MessageFormatParser parser = new MessageFormatParser(features);
			relationshipTarget_cardinality_min_5017Parser = parser;
		}
		return relationshipTarget_cardinality_min_5017Parser;
	}

	/**
	 * @generated
	 */
	private IParser relationshipTarget_cardinality_max_5018Parser;

	/**
	 * @generated
	 */
	private IParser getRelationshipTarget_cardinality_max_5018Parser() {
		if (relationshipTarget_cardinality_max_5018Parser == null) {
			EAttribute[] features = new EAttribute[] { EntityrelationshipPackage.eINSTANCE
					.getRelationship_Target_cardinality_max() };
			MessageFormatParser parser = new MessageFormatParser(features);
			relationshipTarget_cardinality_max_5018Parser = parser;
		}
		return relationshipTarget_cardinality_max_5018Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case StrongEntityNameEditPart.VISUAL_ID:
			return getStrongEntityName_5001Parser();
		case StrongEntityName2EditPart.VISUAL_ID:
			return getStrongEntityName_5002Parser();
		case WeakEntityNameEditPart.VISUAL_ID:
			return getWeakEntityName_5003Parser();
		case WeakEntityName2EditPart.VISUAL_ID:
			return getWeakEntityName_5004Parser();
		case SimpleAttributeNameEditPart.VISUAL_ID:
			return getSimpleAttributeName_5005Parser();
		case SimpleAttributeName2EditPart.VISUAL_ID:
			return getSimpleAttributeName_5006Parser();
		case CompositeAttributeNameEditPart.VISUAL_ID:
			return getCompositeAttributeName_5007Parser();
		case CompositeAttributeName2EditPart.VISUAL_ID:
			return getCompositeAttributeName_5008Parser();
		case OptionalAttributeNameEditPart.VISUAL_ID:
			return getOptionalAttributeName_5009Parser();
		case OptionalAttributeName2EditPart.VISUAL_ID:
			return getOptionalAttributeName_5010Parser();
		case PrimaryKeyAttributeNameEditPart.VISUAL_ID:
			return getPrimaryKeyAttributeName_5011Parser();
		case PrimaryKeyAttributeName2EditPart.VISUAL_ID:
			return getPrimaryKeyAttributeName_5012Parser();
		case RelationshipNameEditPart.VISUAL_ID:
			return getRelationshipName_5013Parser();
		case RelationshipName2EditPart.VISUAL_ID:
			return getRelationshipName_5014Parser();
		case RelationshipSource_cardinality_minEditPart.VISUAL_ID:
			return getRelationshipSource_cardinality_min_5015Parser();
		case RelationshipSource_cardinality_maxEditPart.VISUAL_ID:
			return getRelationshipSource_cardinality_max_5016Parser();
		case RelationshipTarget_cardinality_minEditPart.VISUAL_ID:
			return getRelationshipTarget_cardinality_min_5017Parser();
		case RelationshipTarget_cardinality_maxEditPart.VISUAL_ID:
			return getRelationshipTarget_cardinality_max_5018Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(EntityrelationshipVisualIDRegistry
					.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(EntityrelationshipVisualIDRegistry
					.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (EntityrelationshipElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
