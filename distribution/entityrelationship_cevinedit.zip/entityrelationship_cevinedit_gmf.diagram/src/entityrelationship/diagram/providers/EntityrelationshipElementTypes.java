/*
 * 
 */
package entityrelationship.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypeImages;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypes;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

import entityrelationship.EntityrelationshipPackage;
import entityrelationship.diagram.edit.parts.CompositeAttributeAttributesEditPart;
import entityrelationship.diagram.edit.parts.CompositeAttributeEditPart;
import entityrelationship.diagram.edit.parts.EntityAttributesEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeEditPart;
import entityrelationship.diagram.edit.parts.RelationshipAttributesEditPart;
import entityrelationship.diagram.edit.parts.RelationshipEditPart;
import entityrelationship.diagram.edit.parts.RelationshipSource_entityEditPart;
import entityrelationship.diagram.edit.parts.RelationshipTarget_entityEditPart;
import entityrelationship.diagram.edit.parts.SchemaEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeEditPart;
import entityrelationship.diagram.edit.parts.StrongEntityEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityEditPart;
import entityrelationship.diagram.part.EntityrelationshipDiagramEditorPlugin;

/**
 * @generated
 */
public class EntityrelationshipElementTypes {

	/**
	 * @generated
	 */
	private EntityrelationshipElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map<IElementType, ENamedElement> elements;

	/**
	 * @generated
	 */
	private static DiagramElementTypeImages elementTypeImages = new DiagramElementTypeImages(
			EntityrelationshipDiagramEditorPlugin.getInstance()
					.getItemProvidersAdapterFactory());

	/**
	 * @generated
	 */
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType Schema_1000 = getElementType("entityrelationship_cevinedit_gmf.diagram.Schema_1000"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType StrongEntity_2001 = getElementType("entityrelationship_cevinedit_gmf.diagram.StrongEntity_2001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType WeakEntity_2002 = getElementType("entityrelationship_cevinedit_gmf.diagram.WeakEntity_2002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType SimpleAttribute_2003 = getElementType("entityrelationship_cevinedit_gmf.diagram.SimpleAttribute_2003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType CompositeAttribute_2004 = getElementType("entityrelationship_cevinedit_gmf.diagram.CompositeAttribute_2004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType OptionalAttribute_2005 = getElementType("entityrelationship_cevinedit_gmf.diagram.OptionalAttribute_2005"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType PrimaryKeyAttribute_2006 = getElementType("entityrelationship_cevinedit_gmf.diagram.PrimaryKeyAttribute_2006"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Relationship_2007 = getElementType("entityrelationship_cevinedit_gmf.diagram.Relationship_2007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType EntityAttributes_4001 = getElementType("entityrelationship_cevinedit_gmf.diagram.EntityAttributes_4001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType CompositeAttributeAttributes_4002 = getElementType("entityrelationship_cevinedit_gmf.diagram.CompositeAttributeAttributes_4002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType RelationshipAttributes_4003 = getElementType("entityrelationship_cevinedit_gmf.diagram.RelationshipAttributes_4003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType RelationshipSource_entity_4004 = getElementType("entityrelationship_cevinedit_gmf.diagram.RelationshipSource_entity_4004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType RelationshipTarget_entity_4005 = getElementType("entityrelationship_cevinedit_gmf.diagram.RelationshipTarget_entity_4005"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		return elementTypeImages.getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		return elementTypeImages.getImage(element);
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		return getImageDescriptor(getElement(hint));
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		return getImage(getElement(hint));
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(Schema_1000,
					EntityrelationshipPackage.eINSTANCE.getSchema());

			elements.put(StrongEntity_2001,
					EntityrelationshipPackage.eINSTANCE.getStrongEntity());

			elements.put(WeakEntity_2002,
					EntityrelationshipPackage.eINSTANCE.getWeakEntity());

			elements.put(SimpleAttribute_2003,
					EntityrelationshipPackage.eINSTANCE.getSimpleAttribute());

			elements.put(CompositeAttribute_2004,
					EntityrelationshipPackage.eINSTANCE.getCompositeAttribute());

			elements.put(OptionalAttribute_2005,
					EntityrelationshipPackage.eINSTANCE.getOptionalAttribute());

			elements.put(PrimaryKeyAttribute_2006,
					EntityrelationshipPackage.eINSTANCE
							.getPrimaryKeyAttribute());

			elements.put(Relationship_2007,
					EntityrelationshipPackage.eINSTANCE.getRelationship());

			elements.put(EntityAttributes_4001,
					EntityrelationshipPackage.eINSTANCE.getEntity_Attributes());

			elements.put(CompositeAttributeAttributes_4002,
					EntityrelationshipPackage.eINSTANCE
							.getCompositeAttribute_Attributes());

			elements.put(RelationshipAttributes_4003,
					EntityrelationshipPackage.eINSTANCE
							.getRelationship_Attributes());

			elements.put(RelationshipSource_entity_4004,
					EntityrelationshipPackage.eINSTANCE
							.getRelationship_Source_entity());

			elements.put(RelationshipTarget_entity_4005,
					EntityrelationshipPackage.eINSTANCE
							.getRelationship_Target_entity());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(Schema_1000);
			KNOWN_ELEMENT_TYPES.add(StrongEntity_2001);
			KNOWN_ELEMENT_TYPES.add(WeakEntity_2002);
			KNOWN_ELEMENT_TYPES.add(SimpleAttribute_2003);
			KNOWN_ELEMENT_TYPES.add(CompositeAttribute_2004);
			KNOWN_ELEMENT_TYPES.add(OptionalAttribute_2005);
			KNOWN_ELEMENT_TYPES.add(PrimaryKeyAttribute_2006);
			KNOWN_ELEMENT_TYPES.add(Relationship_2007);
			KNOWN_ELEMENT_TYPES.add(EntityAttributes_4001);
			KNOWN_ELEMENT_TYPES.add(CompositeAttributeAttributes_4002);
			KNOWN_ELEMENT_TYPES.add(RelationshipAttributes_4003);
			KNOWN_ELEMENT_TYPES.add(RelationshipSource_entity_4004);
			KNOWN_ELEMENT_TYPES.add(RelationshipTarget_entity_4005);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	 * @generated
	 */
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case SchemaEditPart.VISUAL_ID:
			return Schema_1000;
		case StrongEntityEditPart.VISUAL_ID:
			return StrongEntity_2001;
		case WeakEntityEditPart.VISUAL_ID:
			return WeakEntity_2002;
		case SimpleAttributeEditPart.VISUAL_ID:
			return SimpleAttribute_2003;
		case CompositeAttributeEditPart.VISUAL_ID:
			return CompositeAttribute_2004;
		case OptionalAttributeEditPart.VISUAL_ID:
			return OptionalAttribute_2005;
		case PrimaryKeyAttributeEditPart.VISUAL_ID:
			return PrimaryKeyAttribute_2006;
		case RelationshipEditPart.VISUAL_ID:
			return Relationship_2007;
		case EntityAttributesEditPart.VISUAL_ID:
			return EntityAttributes_4001;
		case CompositeAttributeAttributesEditPart.VISUAL_ID:
			return CompositeAttributeAttributes_4002;
		case RelationshipAttributesEditPart.VISUAL_ID:
			return RelationshipAttributes_4003;
		case RelationshipSource_entityEditPart.VISUAL_ID:
			return RelationshipSource_entity_4004;
		case RelationshipTarget_entityEditPart.VISUAL_ID:
			return RelationshipTarget_entity_4005;
		}
		return null;
	}

	/**
	 * @generated
	 */
	public static final DiagramElementTypes TYPED_INSTANCE = new DiagramElementTypes(
			elementTypeImages) {

		/**
		 * @generated
		 */
		@Override
		public boolean isKnownElementType(IElementType elementType) {
			return entityrelationship.diagram.providers.EntityrelationshipElementTypes
					.isKnownElementType(elementType);
		}

		/**
		 * @generated
		 */
		@Override
		public IElementType getElementTypeForVisualId(int visualID) {
			return entityrelationship.diagram.providers.EntityrelationshipElementTypes
					.getElementType(visualID);
		}

		/**
		 * @generated
		 */
		@Override
		public ENamedElement getDefiningNamedElement(
				IAdaptable elementTypeAdapter) {
			return entityrelationship.diagram.providers.EntityrelationshipElementTypes
					.getElement(elementTypeAdapter);
		}
	};

}
