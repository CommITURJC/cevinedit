/*
 * 
 */
package entityrelationship.diagram.providers;

import entityrelationship.diagram.part.EntityrelationshipDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = EntityrelationshipDiagramEditorPlugin
				.getInstance().getElementInitializers();
		if (cached == null) {
			EntityrelationshipDiagramEditorPlugin.getInstance()
					.setElementInitializers(cached = new ElementInitializers());
		}
		return cached;
	}
}
