/*
 * 
 */
package entityrelationship.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

import entityrelationship.diagram.edit.parts.EntityrelationshipEditPartFactory;
import entityrelationship.diagram.edit.parts.SchemaEditPart;
import entityrelationship.diagram.part.EntityrelationshipVisualIDRegistry;

/**
 * @generated
 */
public class EntityrelationshipEditPartProvider extends DefaultEditPartProvider {

	/**
	 * @generated
	 */
	public EntityrelationshipEditPartProvider() {
		super(new EntityrelationshipEditPartFactory(),
				EntityrelationshipVisualIDRegistry.TYPED_INSTANCE,
				SchemaEditPart.MODEL_ID);
	}

}
