/*
 * 
 */
package entityrelationship.diagram.navigator;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.common.ui.services.parser.CommonParserHint;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

import entityrelationship.diagram.edit.parts.CompositeAttributeAttributesEditPart;
import entityrelationship.diagram.edit.parts.CompositeAttributeEditPart;
import entityrelationship.diagram.edit.parts.CompositeAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.EntityAttributesEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeEditPart;
import entityrelationship.diagram.edit.parts.OptionalAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeEditPart;
import entityrelationship.diagram.edit.parts.PrimaryKeyAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.RelationshipAttributesEditPart;
import entityrelationship.diagram.edit.parts.RelationshipEditPart;
import entityrelationship.diagram.edit.parts.RelationshipNameEditPart;
import entityrelationship.diagram.edit.parts.RelationshipSource_entityEditPart;
import entityrelationship.diagram.edit.parts.RelationshipTarget_entityEditPart;
import entityrelationship.diagram.edit.parts.SchemaEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeEditPart;
import entityrelationship.diagram.edit.parts.SimpleAttributeNameEditPart;
import entityrelationship.diagram.edit.parts.StrongEntityEditPart;
import entityrelationship.diagram.edit.parts.StrongEntityNameEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityEditPart;
import entityrelationship.diagram.edit.parts.WeakEntityNameEditPart;
import entityrelationship.diagram.part.EntityrelationshipDiagramEditorPlugin;
import entityrelationship.diagram.part.EntityrelationshipVisualIDRegistry;
import entityrelationship.diagram.providers.EntityrelationshipElementTypes;
import entityrelationship.diagram.providers.EntityrelationshipParserProvider;

/**
 * @generated
 */
public class EntityrelationshipNavigatorLabelProvider extends LabelProvider
		implements ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		EntityrelationshipDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		EntityrelationshipDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof EntityrelationshipNavigatorItem
				&& !isOwnView(((EntityrelationshipNavigatorItem) element)
						.getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof EntityrelationshipNavigatorGroup) {
			EntityrelationshipNavigatorGroup group = (EntityrelationshipNavigatorGroup) element;
			return EntityrelationshipDiagramEditorPlugin.getInstance()
					.getBundledImage(group.getIcon());
		}

		if (element instanceof EntityrelationshipNavigatorItem) {
			EntityrelationshipNavigatorItem navigatorItem = (EntityrelationshipNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getImage(view);
			}
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {
		case SchemaEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?http://www.kybele.es/entityrelationship?Schema", EntityrelationshipElementTypes.Schema_1000); //$NON-NLS-1$
		case StrongEntityEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?StrongEntity", EntityrelationshipElementTypes.StrongEntity_2001); //$NON-NLS-1$
		case WeakEntityEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?WeakEntity", EntityrelationshipElementTypes.WeakEntity_2002); //$NON-NLS-1$
		case SimpleAttributeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?SimpleAttribute", EntityrelationshipElementTypes.SimpleAttribute_2003); //$NON-NLS-1$
		case CompositeAttributeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?CompositeAttribute", EntityrelationshipElementTypes.CompositeAttribute_2004); //$NON-NLS-1$
		case OptionalAttributeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?OptionalAttribute", EntityrelationshipElementTypes.OptionalAttribute_2005); //$NON-NLS-1$
		case PrimaryKeyAttributeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?PrimaryKeyAttribute", EntityrelationshipElementTypes.PrimaryKeyAttribute_2006); //$NON-NLS-1$
		case RelationshipEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.kybele.es/entityrelationship?Relationship", EntityrelationshipElementTypes.Relationship_2007); //$NON-NLS-1$
		case EntityAttributesEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.kybele.es/entityrelationship?Entity?attributes", EntityrelationshipElementTypes.EntityAttributes_4001); //$NON-NLS-1$
		case CompositeAttributeAttributesEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.kybele.es/entityrelationship?CompositeAttribute?attributes", EntityrelationshipElementTypes.CompositeAttributeAttributes_4002); //$NON-NLS-1$
		case RelationshipAttributesEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.kybele.es/entityrelationship?Relationship?attributes", EntityrelationshipElementTypes.RelationshipAttributes_4003); //$NON-NLS-1$
		case RelationshipSource_entityEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.kybele.es/entityrelationship?Relationship?source_entity", EntityrelationshipElementTypes.RelationshipSource_entity_4004); //$NON-NLS-1$
		case RelationshipTarget_entityEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.kybele.es/entityrelationship?Relationship?target_entity", EntityrelationshipElementTypes.RelationshipTarget_entity_4005); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = EntityrelationshipDiagramEditorPlugin
				.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null
				&& elementType != null
				&& EntityrelationshipElementTypes
						.isKnownElementType(elementType)) {
			image = EntityrelationshipElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof EntityrelationshipNavigatorGroup) {
			EntityrelationshipNavigatorGroup group = (EntityrelationshipNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof EntityrelationshipNavigatorItem) {
			EntityrelationshipNavigatorItem navigatorItem = (EntityrelationshipNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getText(view);
			}
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (EntityrelationshipVisualIDRegistry.getVisualID(view)) {
		case SchemaEditPart.VISUAL_ID:
			return getSchema_1000Text(view);
		case StrongEntityEditPart.VISUAL_ID:
			return getStrongEntity_2001Text(view);
		case WeakEntityEditPart.VISUAL_ID:
			return getWeakEntity_2002Text(view);
		case SimpleAttributeEditPart.VISUAL_ID:
			return getSimpleAttribute_2003Text(view);
		case CompositeAttributeEditPart.VISUAL_ID:
			return getCompositeAttribute_2004Text(view);
		case OptionalAttributeEditPart.VISUAL_ID:
			return getOptionalAttribute_2005Text(view);
		case PrimaryKeyAttributeEditPart.VISUAL_ID:
			return getPrimaryKeyAttribute_2006Text(view);
		case RelationshipEditPart.VISUAL_ID:
			return getRelationship_2007Text(view);
		case EntityAttributesEditPart.VISUAL_ID:
			return getEntityAttributes_4001Text(view);
		case CompositeAttributeAttributesEditPart.VISUAL_ID:
			return getCompositeAttributeAttributes_4002Text(view);
		case RelationshipAttributesEditPart.VISUAL_ID:
			return getRelationshipAttributes_4003Text(view);
		case RelationshipSource_entityEditPart.VISUAL_ID:
			return getRelationshipSource_entity_4004Text(view);
		case RelationshipTarget_entityEditPart.VISUAL_ID:
			return getRelationshipTarget_entity_4005Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getSchema_1000Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private String getStrongEntity_2001Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.StrongEntity_2001, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(StrongEntityNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getWeakEntity_2002Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.WeakEntity_2002, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(WeakEntityNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSimpleAttribute_2003Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.SimpleAttribute_2003, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(SimpleAttributeNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getCompositeAttribute_2004Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.CompositeAttribute_2004, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(CompositeAttributeNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getOptionalAttribute_2005Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.OptionalAttribute_2005, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(OptionalAttributeNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPrimaryKeyAttribute_2006Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.PrimaryKeyAttribute_2006, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(PrimaryKeyAttributeNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getRelationship_2007Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.Relationship_2007, view
						.getElement() != null ? view.getElement() : view,
				EntityrelationshipVisualIDRegistry
						.getType(RelationshipNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getEntityAttributes_4001Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.EntityAttributes_4001,
				view.getElement() != null ? view.getElement() : view,
				CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getCompositeAttributeAttributes_4002Text(View view) {
		IParser parser = EntityrelationshipParserProvider
				.getParser(
						EntityrelationshipElementTypes.CompositeAttributeAttributes_4002,
						view.getElement() != null ? view.getElement() : view,
						CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 6002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getRelationshipAttributes_4003Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.RelationshipAttributes_4003,
				view.getElement() != null ? view.getElement() : view,
				CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getRelationshipSource_entity_4004Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.RelationshipSource_entity_4004,
				view.getElement() != null ? view.getElement() : view,
				CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 6004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getRelationshipTarget_entity_4005Text(View view) {
		IParser parser = EntityrelationshipParserProvider.getParser(
				EntityrelationshipElementTypes.RelationshipTarget_entity_4005,
				view.getElement() != null ? view.getElement() : view,
				CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			EntityrelationshipDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 6005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return SchemaEditPart.MODEL_ID
				.equals(EntityrelationshipVisualIDRegistry.getModelID(view));
	}

}
