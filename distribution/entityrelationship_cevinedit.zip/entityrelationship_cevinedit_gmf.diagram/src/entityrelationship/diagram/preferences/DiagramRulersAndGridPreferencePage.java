/*
 * 
 */
package entityrelationship.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import entityrelationship.diagram.part.EntityrelationshipDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(EntityrelationshipDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
