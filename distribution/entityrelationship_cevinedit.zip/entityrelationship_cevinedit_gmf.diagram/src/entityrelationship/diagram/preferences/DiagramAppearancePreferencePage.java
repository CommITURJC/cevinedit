/*
 * 
 */
package entityrelationship.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

import entityrelationship.diagram.part.EntityrelationshipDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(EntityrelationshipDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
