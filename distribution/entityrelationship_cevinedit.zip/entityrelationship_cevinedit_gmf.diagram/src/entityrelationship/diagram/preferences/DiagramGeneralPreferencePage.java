/*
 * 
 */
package entityrelationship.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import entityrelationship.diagram.part.EntityrelationshipDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(EntityrelationshipDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
