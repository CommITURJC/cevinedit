/**
 */
package entityrelationship;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relationship</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link entityrelationship.Relationship#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getName <em>Name</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getSource_cardinality_min <em>Source cardinality min</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getSource_cardinality_max <em>Source cardinality max</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getTarget_cardinality_min <em>Target cardinality min</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getTarget_cardinality_max <em>Target cardinality max</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getSource_entity <em>Source entity</em>}</li>
 *   <li>{@link entityrelationship.Relationship#getTarget_entity <em>Target entity</em>}</li>
 * </ul>
 * </p>
 *
 * @see entityrelationship.EntityrelationshipPackage#getRelationship()
 * @model annotation="gmf.node color='255,255,255' border.color='0,0,0' border.style='solid' border.width='2' figure='polygon' polygon.x='200 400 200 0 200' polygon.y='0 100 200 100 0' resizable='true' size='150,75' label.placement='internal' label='name'"
 * @generated
 */
public interface Relationship extends EObject {
	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' reference list.
	 * The list contents are of type {@link entityrelationship.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' reference list.
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Attributes()
	 * @model annotation="gmf.link color='0,0,0' source.decoration='none' target.decoration='none' style='solid' width='1'"
	 * @generated
	 */
	EList<Attribute> getAttributes();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source cardinality min</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source cardinality min</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source cardinality min</em>' attribute.
	 * @see #setSource_cardinality_min(String)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Source_cardinality_min()
	 * @model
	 * @generated
	 */
	String getSource_cardinality_min();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getSource_cardinality_min <em>Source cardinality min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source cardinality min</em>' attribute.
	 * @see #getSource_cardinality_min()
	 * @generated
	 */
	void setSource_cardinality_min(String value);

	/**
	 * Returns the value of the '<em><b>Source cardinality max</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source cardinality max</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source cardinality max</em>' attribute.
	 * @see #setSource_cardinality_max(String)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Source_cardinality_max()
	 * @model
	 * @generated
	 */
	String getSource_cardinality_max();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getSource_cardinality_max <em>Source cardinality max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source cardinality max</em>' attribute.
	 * @see #getSource_cardinality_max()
	 * @generated
	 */
	void setSource_cardinality_max(String value);

	/**
	 * Returns the value of the '<em><b>Target cardinality min</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target cardinality min</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target cardinality min</em>' attribute.
	 * @see #setTarget_cardinality_min(String)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Target_cardinality_min()
	 * @model
	 * @generated
	 */
	String getTarget_cardinality_min();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getTarget_cardinality_min <em>Target cardinality min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target cardinality min</em>' attribute.
	 * @see #getTarget_cardinality_min()
	 * @generated
	 */
	void setTarget_cardinality_min(String value);

	/**
	 * Returns the value of the '<em><b>Target cardinality max</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target cardinality max</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target cardinality max</em>' attribute.
	 * @see #setTarget_cardinality_max(String)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Target_cardinality_max()
	 * @model
	 * @generated
	 */
	String getTarget_cardinality_max();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getTarget_cardinality_max <em>Target cardinality max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target cardinality max</em>' attribute.
	 * @see #getTarget_cardinality_max()
	 * @generated
	 */
	void setTarget_cardinality_max(String value);

	/**
	 * Returns the value of the '<em><b>Source entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source entity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source entity</em>' reference.
	 * @see #setSource_entity(Entity)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Source_entity()
	 * @model annotation="gmf.link color='0,0,0' source.decoration='none' style='solid' width='1'"
	 * @generated
	 */
	Entity getSource_entity();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getSource_entity <em>Source entity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source entity</em>' reference.
	 * @see #getSource_entity()
	 * @generated
	 */
	void setSource_entity(Entity value);

	/**
	 * Returns the value of the '<em><b>Target entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target entity</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target entity</em>' reference.
	 * @see #setTarget_entity(Entity)
	 * @see entityrelationship.EntityrelationshipPackage#getRelationship_Target_entity()
	 * @model annotation="gmf.link color='0,0,0' source.decoration='none' style='solid' width='1'"
	 * @generated
	 */
	Entity getTarget_entity();

	/**
	 * Sets the value of the '{@link entityrelationship.Relationship#getTarget_entity <em>Target entity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target entity</em>' reference.
	 * @see #getTarget_entity()
	 * @generated
	 */
	void setTarget_entity(Entity value);

} // Relationship
