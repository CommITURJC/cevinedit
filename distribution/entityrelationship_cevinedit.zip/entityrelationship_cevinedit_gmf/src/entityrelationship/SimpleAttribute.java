/**
 */
package entityrelationship;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see entityrelationship.EntityrelationshipPackage#getSimpleAttribute()
 * @model annotation="gmf.node color='255,255,255' border.color='0,0,0' border.style='solid' border.width='2' figure='ellipse' resizable='false' size='15,15' label.placement='external' label='name'"
 * @generated
 */
public interface SimpleAttribute extends Attribute {
} // SimpleAttribute
