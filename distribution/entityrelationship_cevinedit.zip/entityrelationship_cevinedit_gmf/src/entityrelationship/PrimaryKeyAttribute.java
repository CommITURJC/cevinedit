/**
 */
package entityrelationship;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primary Key Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see entityrelationship.EntityrelationshipPackage#getPrimaryKeyAttribute()
 * @model annotation="gmf.node color='0,0,0' border.color='0,0,0' border.style='solid' border.width='2' figure='ellipse' resizable='false' size='15,15' label.placement='external' label='name'"
 * @generated
 */
public interface PrimaryKeyAttribute extends Attribute {
} // PrimaryKeyAttribute
