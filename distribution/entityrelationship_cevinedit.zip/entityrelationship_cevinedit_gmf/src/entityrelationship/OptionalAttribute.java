/**
 */
package entityrelationship;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Optional Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see entityrelationship.EntityrelationshipPackage#getOptionalAttribute()
 * @model annotation="gmf.node color='255,255,255' border.color='0,0,0' border.style='dash' border.width='2' figure='ellipse' resizable='false' size='15,15' label.placement='external' label='name'"
 * @generated
 */
public interface OptionalAttribute extends Attribute {
} // OptionalAttribute
