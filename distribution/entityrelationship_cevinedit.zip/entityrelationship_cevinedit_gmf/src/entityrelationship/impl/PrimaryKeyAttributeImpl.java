/**
 */
package entityrelationship.impl;

import entityrelationship.EntityrelationshipPackage;
import entityrelationship.PrimaryKeyAttribute;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primary Key Attribute</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class PrimaryKeyAttributeImpl extends AttributeImpl implements PrimaryKeyAttribute {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PrimaryKeyAttributeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EntityrelationshipPackage.Literals.PRIMARY_KEY_ATTRIBUTE;
	}

} //PrimaryKeyAttributeImpl
