/**
 */
package entityrelationship.impl;

import entityrelationship.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class EntityrelationshipFactoryImpl extends EFactoryImpl implements EntityrelationshipFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static EntityrelationshipFactory init() {
		try {
			EntityrelationshipFactory theEntityrelationshipFactory = (EntityrelationshipFactory)EPackage.Registry.INSTANCE.getEFactory(EntityrelationshipPackage.eNS_URI);
			if (theEntityrelationshipFactory != null) {
				return theEntityrelationshipFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new EntityrelationshipFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntityrelationshipFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case EntityrelationshipPackage.SCHEMA: return createSchema();
			case EntityrelationshipPackage.STRONG_ENTITY: return createStrongEntity();
			case EntityrelationshipPackage.WEAK_ENTITY: return createWeakEntity();
			case EntityrelationshipPackage.SIMPLE_ATTRIBUTE: return createSimpleAttribute();
			case EntityrelationshipPackage.COMPOSITE_ATTRIBUTE: return createCompositeAttribute();
			case EntityrelationshipPackage.OPTIONAL_ATTRIBUTE: return createOptionalAttribute();
			case EntityrelationshipPackage.PRIMARY_KEY_ATTRIBUTE: return createPrimaryKeyAttribute();
			case EntityrelationshipPackage.RELATIONSHIP: return createRelationship();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Schema createSchema() {
		SchemaImpl schema = new SchemaImpl();
		return schema;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StrongEntity createStrongEntity() {
		StrongEntityImpl strongEntity = new StrongEntityImpl();
		return strongEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WeakEntity createWeakEntity() {
		WeakEntityImpl weakEntity = new WeakEntityImpl();
		return weakEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SimpleAttribute createSimpleAttribute() {
		SimpleAttributeImpl simpleAttribute = new SimpleAttributeImpl();
		return simpleAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CompositeAttribute createCompositeAttribute() {
		CompositeAttributeImpl compositeAttribute = new CompositeAttributeImpl();
		return compositeAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OptionalAttribute createOptionalAttribute() {
		OptionalAttributeImpl optionalAttribute = new OptionalAttributeImpl();
		return optionalAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PrimaryKeyAttribute createPrimaryKeyAttribute() {
		PrimaryKeyAttributeImpl primaryKeyAttribute = new PrimaryKeyAttributeImpl();
		return primaryKeyAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Relationship createRelationship() {
		RelationshipImpl relationship = new RelationshipImpl();
		return relationship;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntityrelationshipPackage getEntityrelationshipPackage() {
		return (EntityrelationshipPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static EntityrelationshipPackage getPackage() {
		return EntityrelationshipPackage.eINSTANCE;
	}

} //EntityrelationshipFactoryImpl
