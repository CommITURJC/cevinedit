/**
 */
package entityrelationship.impl;

import entityrelationship.Attribute;
import entityrelationship.Entity;
import entityrelationship.EntityrelationshipPackage;
import entityrelationship.Relationship;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Relationship</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getName <em>Name</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getSource_cardinality_min <em>Source cardinality min</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getSource_cardinality_max <em>Source cardinality max</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getTarget_cardinality_min <em>Target cardinality min</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getTarget_cardinality_max <em>Target cardinality max</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getSource_entity <em>Source entity</em>}</li>
 *   <li>{@link entityrelationship.impl.RelationshipImpl#getTarget_entity <em>Target entity</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RelationshipImpl extends EObjectImpl implements Relationship {
	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attributes;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSource_cardinality_min() <em>Source cardinality min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource_cardinality_min()
	 * @generated
	 * @ordered
	 */
	protected static final String SOURCE_CARDINALITY_MIN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSource_cardinality_min() <em>Source cardinality min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource_cardinality_min()
	 * @generated
	 * @ordered
	 */
	protected String source_cardinality_min = SOURCE_CARDINALITY_MIN_EDEFAULT;

	/**
	 * The default value of the '{@link #getSource_cardinality_max() <em>Source cardinality max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource_cardinality_max()
	 * @generated
	 * @ordered
	 */
	protected static final String SOURCE_CARDINALITY_MAX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSource_cardinality_max() <em>Source cardinality max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource_cardinality_max()
	 * @generated
	 * @ordered
	 */
	protected String source_cardinality_max = SOURCE_CARDINALITY_MAX_EDEFAULT;

	/**
	 * The default value of the '{@link #getTarget_cardinality_min() <em>Target cardinality min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget_cardinality_min()
	 * @generated
	 * @ordered
	 */
	protected static final String TARGET_CARDINALITY_MIN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTarget_cardinality_min() <em>Target cardinality min</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget_cardinality_min()
	 * @generated
	 * @ordered
	 */
	protected String target_cardinality_min = TARGET_CARDINALITY_MIN_EDEFAULT;

	/**
	 * The default value of the '{@link #getTarget_cardinality_max() <em>Target cardinality max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget_cardinality_max()
	 * @generated
	 * @ordered
	 */
	protected static final String TARGET_CARDINALITY_MAX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTarget_cardinality_max() <em>Target cardinality max</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget_cardinality_max()
	 * @generated
	 * @ordered
	 */
	protected String target_cardinality_max = TARGET_CARDINALITY_MAX_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSource_entity() <em>Source entity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource_entity()
	 * @generated
	 * @ordered
	 */
	protected Entity source_entity;

	/**
	 * The cached value of the '{@link #getTarget_entity() <em>Target entity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget_entity()
	 * @generated
	 * @ordered
	 */
	protected Entity target_entity;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RelationshipImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EntityrelationshipPackage.Literals.RELATIONSHIP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attribute> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectResolvingEList<Attribute>(Attribute.class, this, EntityrelationshipPackage.RELATIONSHIP__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSource_cardinality_min() {
		return source_cardinality_min;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource_cardinality_min(String newSource_cardinality_min) {
		String oldSource_cardinality_min = source_cardinality_min;
		source_cardinality_min = newSource_cardinality_min;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MIN, oldSource_cardinality_min, source_cardinality_min));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSource_cardinality_max() {
		return source_cardinality_max;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource_cardinality_max(String newSource_cardinality_max) {
		String oldSource_cardinality_max = source_cardinality_max;
		source_cardinality_max = newSource_cardinality_max;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MAX, oldSource_cardinality_max, source_cardinality_max));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTarget_cardinality_min() {
		return target_cardinality_min;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTarget_cardinality_min(String newTarget_cardinality_min) {
		String oldTarget_cardinality_min = target_cardinality_min;
		target_cardinality_min = newTarget_cardinality_min;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MIN, oldTarget_cardinality_min, target_cardinality_min));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTarget_cardinality_max() {
		return target_cardinality_max;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTarget_cardinality_max(String newTarget_cardinality_max) {
		String oldTarget_cardinality_max = target_cardinality_max;
		target_cardinality_max = newTarget_cardinality_max;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MAX, oldTarget_cardinality_max, target_cardinality_max));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entity getSource_entity() {
		if (source_entity != null && source_entity.eIsProxy()) {
			InternalEObject oldSource_entity = (InternalEObject)source_entity;
			source_entity = (Entity)eResolveProxy(oldSource_entity);
			if (source_entity != oldSource_entity) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, EntityrelationshipPackage.RELATIONSHIP__SOURCE_ENTITY, oldSource_entity, source_entity));
			}
		}
		return source_entity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entity basicGetSource_entity() {
		return source_entity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource_entity(Entity newSource_entity) {
		Entity oldSource_entity = source_entity;
		source_entity = newSource_entity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__SOURCE_ENTITY, oldSource_entity, source_entity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entity getTarget_entity() {
		if (target_entity != null && target_entity.eIsProxy()) {
			InternalEObject oldTarget_entity = (InternalEObject)target_entity;
			target_entity = (Entity)eResolveProxy(oldTarget_entity);
			if (target_entity != oldTarget_entity) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, EntityrelationshipPackage.RELATIONSHIP__TARGET_ENTITY, oldTarget_entity, target_entity));
			}
		}
		return target_entity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entity basicGetTarget_entity() {
		return target_entity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTarget_entity(Entity newTarget_entity) {
		Entity oldTarget_entity = target_entity;
		target_entity = newTarget_entity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, EntityrelationshipPackage.RELATIONSHIP__TARGET_ENTITY, oldTarget_entity, target_entity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case EntityrelationshipPackage.RELATIONSHIP__ATTRIBUTES:
				return getAttributes();
			case EntityrelationshipPackage.RELATIONSHIP__NAME:
				return getName();
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MIN:
				return getSource_cardinality_min();
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MAX:
				return getSource_cardinality_max();
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MIN:
				return getTarget_cardinality_min();
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MAX:
				return getTarget_cardinality_max();
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_ENTITY:
				if (resolve) return getSource_entity();
				return basicGetSource_entity();
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_ENTITY:
				if (resolve) return getTarget_entity();
				return basicGetTarget_entity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case EntityrelationshipPackage.RELATIONSHIP__ATTRIBUTES:
				getAttributes().clear();
				getAttributes().addAll((Collection<? extends Attribute>)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__NAME:
				setName((String)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MIN:
				setSource_cardinality_min((String)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MAX:
				setSource_cardinality_max((String)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MIN:
				setTarget_cardinality_min((String)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MAX:
				setTarget_cardinality_max((String)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_ENTITY:
				setSource_entity((Entity)newValue);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_ENTITY:
				setTarget_entity((Entity)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case EntityrelationshipPackage.RELATIONSHIP__ATTRIBUTES:
				getAttributes().clear();
				return;
			case EntityrelationshipPackage.RELATIONSHIP__NAME:
				setName(NAME_EDEFAULT);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MIN:
				setSource_cardinality_min(SOURCE_CARDINALITY_MIN_EDEFAULT);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MAX:
				setSource_cardinality_max(SOURCE_CARDINALITY_MAX_EDEFAULT);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MIN:
				setTarget_cardinality_min(TARGET_CARDINALITY_MIN_EDEFAULT);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MAX:
				setTarget_cardinality_max(TARGET_CARDINALITY_MAX_EDEFAULT);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_ENTITY:
				setSource_entity((Entity)null);
				return;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_ENTITY:
				setTarget_entity((Entity)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case EntityrelationshipPackage.RELATIONSHIP__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
			case EntityrelationshipPackage.RELATIONSHIP__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MIN:
				return SOURCE_CARDINALITY_MIN_EDEFAULT == null ? source_cardinality_min != null : !SOURCE_CARDINALITY_MIN_EDEFAULT.equals(source_cardinality_min);
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_CARDINALITY_MAX:
				return SOURCE_CARDINALITY_MAX_EDEFAULT == null ? source_cardinality_max != null : !SOURCE_CARDINALITY_MAX_EDEFAULT.equals(source_cardinality_max);
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MIN:
				return TARGET_CARDINALITY_MIN_EDEFAULT == null ? target_cardinality_min != null : !TARGET_CARDINALITY_MIN_EDEFAULT.equals(target_cardinality_min);
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_CARDINALITY_MAX:
				return TARGET_CARDINALITY_MAX_EDEFAULT == null ? target_cardinality_max != null : !TARGET_CARDINALITY_MAX_EDEFAULT.equals(target_cardinality_max);
			case EntityrelationshipPackage.RELATIONSHIP__SOURCE_ENTITY:
				return source_entity != null;
			case EntityrelationshipPackage.RELATIONSHIP__TARGET_ENTITY:
				return target_entity != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", source_cardinality_min: ");
		result.append(source_cardinality_min);
		result.append(", source_cardinality_max: ");
		result.append(source_cardinality_max);
		result.append(", target_cardinality_min: ");
		result.append(target_cardinality_min);
		result.append(", target_cardinality_max: ");
		result.append(target_cardinality_max);
		result.append(')');
		return result.toString();
	}

} //RelationshipImpl
