/**
 */
package entityrelationship.impl;

import entityrelationship.Attribute;
import entityrelationship.CompositeAttribute;
import entityrelationship.Entity;
import entityrelationship.EntityrelationshipFactory;
import entityrelationship.EntityrelationshipPackage;
import entityrelationship.OptionalAttribute;
import entityrelationship.PrimaryKeyAttribute;
import entityrelationship.Relationship;
import entityrelationship.Schema;
import entityrelationship.SimpleAttribute;
import entityrelationship.StrongEntity;
import entityrelationship.WeakEntity;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class EntityrelationshipPackageImpl extends EPackageImpl implements EntityrelationshipPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass schemaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass entityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass strongEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass weakEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass compositeAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass optionalAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass primaryKeyAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass relationshipEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see entityrelationship.EntityrelationshipPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private EntityrelationshipPackageImpl() {
		super(eNS_URI, EntityrelationshipFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link EntityrelationshipPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static EntityrelationshipPackage init() {
		if (isInited) return (EntityrelationshipPackage)EPackage.Registry.INSTANCE.getEPackage(EntityrelationshipPackage.eNS_URI);

		// Obtain or create and register package
		EntityrelationshipPackageImpl theEntityrelationshipPackage = (EntityrelationshipPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof EntityrelationshipPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new EntityrelationshipPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theEntityrelationshipPackage.createPackageContents();

		// Initialize created meta-data
		theEntityrelationshipPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theEntityrelationshipPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(EntityrelationshipPackage.eNS_URI, theEntityrelationshipPackage);
		return theEntityrelationshipPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSchema() {
		return schemaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSchema_Entities() {
		return (EReference)schemaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSchema_Relationships() {
		return (EReference)schemaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSchema_Attributes() {
		return (EReference)schemaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEntity() {
		return entityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEntity_Name() {
		return (EAttribute)entityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntity_Attributes() {
		return (EReference)entityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStrongEntity() {
		return strongEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWeakEntity() {
		return weakEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttribute() {
		return attributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Name() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleAttribute() {
		return simpleAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCompositeAttribute() {
		return compositeAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCompositeAttribute_Attributes() {
		return (EReference)compositeAttributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOptionalAttribute() {
		return optionalAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPrimaryKeyAttribute() {
		return primaryKeyAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRelationship() {
		return relationshipEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelationship_Attributes() {
		return (EReference)relationshipEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelationship_Name() {
		return (EAttribute)relationshipEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelationship_Source_cardinality_min() {
		return (EAttribute)relationshipEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelationship_Source_cardinality_max() {
		return (EAttribute)relationshipEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelationship_Target_cardinality_min() {
		return (EAttribute)relationshipEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelationship_Target_cardinality_max() {
		return (EAttribute)relationshipEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelationship_Source_entity() {
		return (EReference)relationshipEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelationship_Target_entity() {
		return (EReference)relationshipEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntityrelationshipFactory getEntityrelationshipFactory() {
		return (EntityrelationshipFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		schemaEClass = createEClass(SCHEMA);
		createEReference(schemaEClass, SCHEMA__ENTITIES);
		createEReference(schemaEClass, SCHEMA__RELATIONSHIPS);
		createEReference(schemaEClass, SCHEMA__ATTRIBUTES);

		entityEClass = createEClass(ENTITY);
		createEAttribute(entityEClass, ENTITY__NAME);
		createEReference(entityEClass, ENTITY__ATTRIBUTES);

		strongEntityEClass = createEClass(STRONG_ENTITY);

		weakEntityEClass = createEClass(WEAK_ENTITY);

		attributeEClass = createEClass(ATTRIBUTE);
		createEAttribute(attributeEClass, ATTRIBUTE__NAME);

		simpleAttributeEClass = createEClass(SIMPLE_ATTRIBUTE);

		compositeAttributeEClass = createEClass(COMPOSITE_ATTRIBUTE);
		createEReference(compositeAttributeEClass, COMPOSITE_ATTRIBUTE__ATTRIBUTES);

		optionalAttributeEClass = createEClass(OPTIONAL_ATTRIBUTE);

		primaryKeyAttributeEClass = createEClass(PRIMARY_KEY_ATTRIBUTE);

		relationshipEClass = createEClass(RELATIONSHIP);
		createEReference(relationshipEClass, RELATIONSHIP__ATTRIBUTES);
		createEAttribute(relationshipEClass, RELATIONSHIP__NAME);
		createEAttribute(relationshipEClass, RELATIONSHIP__SOURCE_CARDINALITY_MIN);
		createEAttribute(relationshipEClass, RELATIONSHIP__SOURCE_CARDINALITY_MAX);
		createEAttribute(relationshipEClass, RELATIONSHIP__TARGET_CARDINALITY_MIN);
		createEAttribute(relationshipEClass, RELATIONSHIP__TARGET_CARDINALITY_MAX);
		createEReference(relationshipEClass, RELATIONSHIP__SOURCE_ENTITY);
		createEReference(relationshipEClass, RELATIONSHIP__TARGET_ENTITY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		strongEntityEClass.getESuperTypes().add(this.getEntity());
		weakEntityEClass.getESuperTypes().add(this.getEntity());
		simpleAttributeEClass.getESuperTypes().add(this.getAttribute());
		compositeAttributeEClass.getESuperTypes().add(this.getAttribute());
		optionalAttributeEClass.getESuperTypes().add(this.getAttribute());
		primaryKeyAttributeEClass.getESuperTypes().add(this.getAttribute());

		// Initialize classes and features; add operations and parameters
		initEClass(schemaEClass, Schema.class, "Schema", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSchema_Entities(), this.getEntity(), null, "entities", null, 0, -1, Schema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSchema_Relationships(), this.getRelationship(), null, "relationships", null, 0, -1, Schema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSchema_Attributes(), this.getAttribute(), null, "attributes", null, 0, -1, Schema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(entityEClass, Entity.class, "Entity", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEntity_Name(), ecorePackage.getEString(), "name", null, 0, 1, Entity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntity_Attributes(), this.getAttribute(), null, "attributes", null, 0, -1, Entity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(strongEntityEClass, StrongEntity.class, "StrongEntity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(weakEntityEClass, WeakEntity.class, "WeakEntity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(attributeEClass, Attribute.class, "Attribute", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAttribute_Name(), ecorePackage.getEString(), "name", null, 0, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(simpleAttributeEClass, SimpleAttribute.class, "SimpleAttribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(compositeAttributeEClass, CompositeAttribute.class, "CompositeAttribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCompositeAttribute_Attributes(), this.getSimpleAttribute(), null, "attributes", null, 0, -1, CompositeAttribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(optionalAttributeEClass, OptionalAttribute.class, "OptionalAttribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(primaryKeyAttributeEClass, PrimaryKeyAttribute.class, "PrimaryKeyAttribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(relationshipEClass, Relationship.class, "Relationship", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRelationship_Attributes(), this.getAttribute(), null, "attributes", null, 0, -1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelationship_Name(), ecorePackage.getEString(), "name", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelationship_Source_cardinality_min(), ecorePackage.getEString(), "source_cardinality_min", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelationship_Source_cardinality_max(), ecorePackage.getEString(), "source_cardinality_max", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelationship_Target_cardinality_min(), ecorePackage.getEString(), "target_cardinality_min", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelationship_Target_cardinality_max(), ecorePackage.getEString(), "target_cardinality_max", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRelationship_Source_entity(), this.getEntity(), null, "source_entity", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRelationship_Target_entity(), this.getEntity(), null, "target_entity", null, 0, 1, Relationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// gmf
		createGmfAnnotations();
		// gmf.diagram
		createGmf_1Annotations();
		// gmf.label
		createGmf_2Annotations();
		// gmf.link
		createGmf_3Annotations();
		// gmf.node
		createGmf_4Annotations();
	}

	/**
	 * Initializes the annotations for <b>gmf</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmfAnnotations() {
		String source = "gmf";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.diagram</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_1Annotations() {
		String source = "gmf.diagram";	
		addAnnotation
		  (schemaEClass, 
		   source, 
		   new String[] {
			 "model.extension", "entityrelationship_model",
			 "diagram.extension", "entityrelationship_diagram"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.label</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_2Annotations() {
		String source = "gmf.label";	
		addAnnotation
		  (getEntity_Name(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getAttribute_Name(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getRelationship_Name(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getRelationship_Source_cardinality_min(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getRelationship_Source_cardinality_max(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getRelationship_Target_cardinality_min(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getRelationship_Target_cardinality_max(), 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.link</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_3Annotations() {
		String source = "gmf.link";	
		addAnnotation
		  (getEntity_Attributes(), 
		   source, 
		   new String[] {
			 "color", "0,0,0",
			 "source.decoration", "none",
			 "target.decoration", "none",
			 "style", "solid",
			 "width", "1"
		   });	
		addAnnotation
		  (getCompositeAttribute_Attributes(), 
		   source, 
		   new String[] {
			 "color", "0,0,0",
			 "source.decoration", "none",
			 "style", "dash",
			 "width", "1"
		   });	
		addAnnotation
		  (getRelationship_Attributes(), 
		   source, 
		   new String[] {
			 "color", "0,0,0",
			 "source.decoration", "none",
			 "target.decoration", "none",
			 "style", "solid",
			 "width", "1"
		   });	
		addAnnotation
		  (getRelationship_Source_entity(), 
		   source, 
		   new String[] {
			 "color", "0,0,0",
			 "source.decoration", "none",
			 "style", "solid",
			 "width", "1"
		   });	
		addAnnotation
		  (getRelationship_Target_entity(), 
		   source, 
		   new String[] {
			 "color", "0,0,0",
			 "source.decoration", "none",
			 "style", "solid",
			 "width", "1"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.node</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_4Annotations() {
		String source = "gmf.node";	
		addAnnotation
		  (strongEntityEClass, 
		   source, 
		   new String[] {
			 "color", "255,255,255",
			 "border.color", "0,0,0",
			 "border.style", "solid",
			 "border.width", "2",
			 "figure", "rectangle",
			 "resizable", "true",
			 "label.placement", "internal",
			 "label", "name"
		   });	
		addAnnotation
		  (weakEntityEClass, 
		   source, 
		   new String[] {
			 "color", "255,255,255",
			 "border.color", "0,0,0",
			 "border.style", "dash",
			 "border.width", "2",
			 "figure", "rectangle",
			 "resizable", "true",
			 "label.placement", "internal",
			 "label", "name"
		   });	
		addAnnotation
		  (simpleAttributeEClass, 
		   source, 
		   new String[] {
			 "color", "255,255,255",
			 "border.color", "0,0,0",
			 "border.style", "solid",
			 "border.width", "2",
			 "figure", "ellipse",
			 "resizable", "false",
			 "size", "15,15",
			 "label.placement", "external",
			 "label", "name"
		   });	
		addAnnotation
		  (compositeAttributeEClass, 
		   source, 
		   new String[] {
			 "color", "255,255,255",
			 "border.color", "0,0,0",
			 "border.style", "dot",
			 "border.width", "2",
			 "figure", "ellipse",
			 "resizable", "false",
			 "size", "15,15",
			 "label.placement", "external",
			 "label", "name"
		   });	
		addAnnotation
		  (optionalAttributeEClass, 
		   source, 
		   new String[] {
			 "color", "255,255,255",
			 "border.color", "0,0,0",
			 "border.style", "dash",
			 "border.width", "2",
			 "figure", "ellipse",
			 "resizable", "false",
			 "size", "15,15",
			 "label.placement", "external",
			 "label", "name"
		   });	
		addAnnotation
		  (primaryKeyAttributeEClass, 
		   source, 
		   new String[] {
			 "color", "0,0,0",
			 "border.color", "0,0,0",
			 "border.style", "solid",
			 "border.width", "2",
			 "figure", "ellipse",
			 "resizable", "false",
			 "size", "15,15",
			 "label.placement", "external",
			 "label", "name"
		   });	
		addAnnotation
		  (relationshipEClass, 
		   source, 
		   new String[] {
			 "color", "255,255,255",
			 "border.color", "0,0,0",
			 "border.style", "solid",
			 "border.width", "2",
			 "figure", "polygon",
			 "polygon.x", "200 400 200 0 200",
			 "polygon.y", "0 100 200 100 0",
			 "resizable", "true",
			 "size", "150,75",
			 "label.placement", "internal",
			 "label", "name"
		   });
	}

} //EntityrelationshipPackageImpl
