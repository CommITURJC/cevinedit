/**
 */
package entityrelationship;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composite Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link entityrelationship.CompositeAttribute#getAttributes <em>Attributes</em>}</li>
 * </ul>
 * </p>
 *
 * @see entityrelationship.EntityrelationshipPackage#getCompositeAttribute()
 * @model annotation="gmf.node color='255,255,255' border.color='0,0,0' border.style='dot' border.width='2' figure='ellipse' resizable='false' size='15,15' label.placement='external' label='name'"
 * @generated
 */
public interface CompositeAttribute extends Attribute {
	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' reference list.
	 * The list contents are of type {@link entityrelationship.SimpleAttribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' reference list.
	 * @see entityrelationship.EntityrelationshipPackage#getCompositeAttribute_Attributes()
	 * @model annotation="gmf.link color='0,0,0' source.decoration='none' style='dash' width='1'"
	 * @generated
	 */
	EList<SimpleAttribute> getAttributes();

} // CompositeAttribute
