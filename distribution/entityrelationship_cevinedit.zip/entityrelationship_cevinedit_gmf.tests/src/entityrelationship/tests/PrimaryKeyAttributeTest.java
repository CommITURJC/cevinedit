/**
 */
package entityrelationship.tests;

import entityrelationship.EntityrelationshipFactory;
import entityrelationship.PrimaryKeyAttribute;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Primary Key Attribute</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class PrimaryKeyAttributeTest extends AttributeTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(PrimaryKeyAttributeTest.class);
	}

	/**
	 * Constructs a new Primary Key Attribute test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PrimaryKeyAttributeTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Primary Key Attribute test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected PrimaryKeyAttribute getFixture() {
		return (PrimaryKeyAttribute)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(EntityrelationshipFactory.eINSTANCE.createPrimaryKeyAttribute());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //PrimaryKeyAttributeTest
