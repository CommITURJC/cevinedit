package org.cevinedit.editor.view.dialogs;


public class EClassTransforms {

	public static final int EClassToDiagram = 0;
	public static final int EClassToNode = 1;
	public static final int EClassToLink = 2;
	
}
