package org.cevinedit.editor.view.constants;

public class CevineditEEnums {

	public static String COLOR = "Color";
	public static String TEXTURE = "Texture";
	public static String BRIGHTNESS = "Brightness";
	public static String FONTSTYLE = "FontStyle";
	public static String NODEFIGURE = "NodeFigure";
	public static String LINKFIGURE = "LinkFigure";
	public static String PLACEMENT = "Placement";
	public static String LAYOUTCOMPARTMENT = "LayoutCompartment";
}
