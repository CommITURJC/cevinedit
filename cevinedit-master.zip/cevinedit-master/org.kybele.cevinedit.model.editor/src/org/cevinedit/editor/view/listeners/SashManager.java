package org.cevinedit.editor.view.listeners;

import org.eclipse.swt.custom.SashForm;

public class SashManager {

	public static void setWeights(SashForm sash, int []wights)
	{
		sash.setWeights(wights);
	}
	
}
