package org.cevinedit.editor.view.constants;

public class CevineditHtmlHelpPages {
	
	public static String INDEX = "Color.html";
	
	public static String BRIGHTNESS = "Brightness.html";
	public static String COLOR = "Color.html";
	public static String FONTSTYLE = "DualCoding.html";
	public static String LAYOUT_COMPARTMENT = "Location.html";
	public static String LINK_FIGURE = "Shape.html";
	public static String NODE_FIGURE = "Shape.html";
	public static String PLACEMENT = "Location.html";
	public static String TEXTURE = "Texture.html";
	public static String WIDTH = "Size.html";
	public static String LABEL = "Label.html";
	public static String SIZE = "Size.html";
	public static String RESIZABLE = "Size.html";
	
	
	
}
