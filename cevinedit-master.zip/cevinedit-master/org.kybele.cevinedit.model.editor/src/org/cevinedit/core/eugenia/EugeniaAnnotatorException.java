package org.cevinedit.core.eugenia;

public class EugeniaAnnotatorException extends Exception {

	public EugeniaAnnotatorException(String message)
	{
		super(message);
	}
}
