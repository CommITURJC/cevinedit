package org.cevinedit.core.eugenia;

import java.util.LinkedList;
import java.util.List;

public class EugeniaLayout {
	public static String LAYOUT_FREE = "free";
	public static String LAYOUT_LIST = "list";
	
	public static List<String> list()
	{
		LinkedList<String> layouts = new LinkedList<>();
		
		layouts.add(LAYOUT_FREE);
		layouts.add(LAYOUT_LIST);

		
		return layouts;
	}
	
	public static boolean isLayout(String style)
	{
		return list().contains(style);
	}	
}
