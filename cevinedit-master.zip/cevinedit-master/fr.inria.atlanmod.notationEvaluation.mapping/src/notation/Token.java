/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends TextualElement {
} // Token
