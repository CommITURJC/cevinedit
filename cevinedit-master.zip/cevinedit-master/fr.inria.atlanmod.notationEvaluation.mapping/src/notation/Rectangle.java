/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rectangle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getRectangle()
 * @model
 * @generated
 */
public interface Rectangle extends Figure {
} // Rectangle
