/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cube</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getCube()
 * @model
 * @generated
 */
public interface Cube extends Figure {
} // Cube
