/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Triangle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getTriangle()
 * @model
 * @generated
 */
public interface Triangle extends Figure {
} // Triangle
