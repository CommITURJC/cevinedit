/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diagram Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getDiagramElement()
 * @model abstract="true"
 * @generated
 */
public interface DiagramElement extends IDElement {
} // DiagramElement
