/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Roundtangle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getRoundtangle()
 * @model
 * @generated
 */
public interface Roundtangle extends Figure {
} // Roundtangle
