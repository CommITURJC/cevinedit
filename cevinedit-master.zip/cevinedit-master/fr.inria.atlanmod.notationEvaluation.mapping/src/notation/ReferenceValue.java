/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reference Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getReferenceValue()
 * @model
 * @generated
 */
public interface ReferenceValue extends Value {
} // ReferenceValue
