/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getAttributeValue()
 * @model
 * @generated
 */
public interface AttributeValue extends Value {
} // AttributeValue
