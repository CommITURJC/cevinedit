/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Square</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getSquare()
 * @model
 * @generated
 */
public interface Square extends Figure {
} // Square
