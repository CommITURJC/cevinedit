/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cylinder</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getCylinder()
 * @model
 * @generated
 */
public interface Cylinder extends Figure {
} // Cylinder
