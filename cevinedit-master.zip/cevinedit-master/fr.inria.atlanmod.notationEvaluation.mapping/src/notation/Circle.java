/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Circle</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getCircle()
 * @model
 * @generated
 */
public interface Circle extends Figure {
} // Circle
