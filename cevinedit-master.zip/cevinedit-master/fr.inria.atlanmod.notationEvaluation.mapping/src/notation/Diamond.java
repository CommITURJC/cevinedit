/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diamond</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getDiamond()
 * @model
 * @generated
 */
public interface Diamond extends Figure {
} // Diamond
