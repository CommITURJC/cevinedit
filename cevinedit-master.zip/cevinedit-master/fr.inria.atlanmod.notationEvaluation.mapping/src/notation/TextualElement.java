/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Textual Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getTextualElement()
 * @model abstract="true"
 * @generated
 */
public interface TextualElement extends IDElement {
} // TextualElement
