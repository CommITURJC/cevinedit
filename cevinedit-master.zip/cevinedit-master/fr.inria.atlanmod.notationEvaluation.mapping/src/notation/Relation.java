/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getRelation()
 * @model abstract="true"
 * @generated
 */
public interface Relation extends DiagramElement {
} // Relation
