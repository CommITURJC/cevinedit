/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Keyword</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getKeyword()
 * @model
 * @generated
 */
public interface Keyword extends TextualElement {
} // Keyword
