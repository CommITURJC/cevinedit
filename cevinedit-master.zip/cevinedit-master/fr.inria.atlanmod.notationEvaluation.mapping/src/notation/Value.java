/**
 */
package notation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see notation.NotationPackage#getValue()
 * @model abstract="true"
 * @generated
 */
public interface Value extends TextualElement {
} // Value
