/**
 */
package cevinedit.tests;

import cevinedit.CevineditFactory;
import cevinedit.CompartmentEReferenceCont;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Compartment EReference Cont</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class CompartmentEReferenceContTest extends PersonalizedElementTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(CompartmentEReferenceContTest.class);
	}

	/**
	 * Constructs a new Compartment EReference Cont test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CompartmentEReferenceContTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Compartment EReference Cont test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected CompartmentEReferenceCont getFixture() {
		return (CompartmentEReferenceCont)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(CevineditFactory.eINSTANCE.createCompartmentEReferenceCont());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //CompartmentEReferenceContTest
