/**
 */
package cevinedit.tests;

import cevinedit.PersonalizedElement;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Personalized Element</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PersonalizedElementTest extends TestCase {

	/**
	 * The fixture for this Personalized Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PersonalizedElement fixture = null;

	/**
	 * Constructs a new Personalized Element test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PersonalizedElementTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Personalized Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(PersonalizedElement fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Personalized Element test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PersonalizedElement getFixture() {
		return fixture;
	}

} //PersonalizedElementTest
