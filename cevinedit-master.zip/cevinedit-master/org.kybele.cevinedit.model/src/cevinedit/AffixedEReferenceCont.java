/**
 */
package cevinedit;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Affixed EReference Cont</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see cevinedit.CevineditPackage#getAffixedEReferenceCont()
 * @model
 * @generated
 */
public interface AffixedEReferenceCont extends PersonalizedElement {
} // AffixedEReferenceCont
