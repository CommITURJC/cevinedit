/**
 */
package cevinedit.impl;

import cevinedit.AffixedEReferenceCont;
import cevinedit.CevineditPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Affixed EReference Cont</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AffixedEReferenceContImpl extends PersonalizedElementImpl implements AffixedEReferenceCont {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AffixedEReferenceContImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CevineditPackage.Literals.AFFIXED_EREFERENCE_CONT;
	}

} //AffixedEReferenceContImpl
