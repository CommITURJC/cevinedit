/**
 */
package cevinedit;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Label EAttribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see cevinedit.CevineditPackage#getLabelEAttribute()
 * @model
 * @generated
 */
public interface LabelEAttribute extends PersonalizedElement {
} // LabelEAttribute
