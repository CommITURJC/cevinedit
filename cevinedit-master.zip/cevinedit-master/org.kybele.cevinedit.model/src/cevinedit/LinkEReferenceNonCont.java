/**
 */
package cevinedit;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Link EReference Non Cont</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see cevinedit.CevineditPackage#getLinkEReferenceNonCont()
 * @model
 * @generated
 */
public interface LinkEReferenceNonCont extends PersonalizedElement, Link {
} // LinkEReferenceNonCont
