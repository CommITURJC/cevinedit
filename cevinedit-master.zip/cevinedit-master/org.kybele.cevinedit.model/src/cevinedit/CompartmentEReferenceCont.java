/**
 */
package cevinedit;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Compartment EReference Cont</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link cevinedit.CompartmentEReferenceCont#isCollapsible <em>Collapsible</em>}</li>
 *   <li>{@link cevinedit.CompartmentEReferenceCont#getLayout <em>Layout</em>}</li>
 * </ul>
 * </p>
 *
 * @see cevinedit.CevineditPackage#getCompartmentEReferenceCont()
 * @model
 * @generated
 */
public interface CompartmentEReferenceCont extends PersonalizedElement {
	/**
	 * Returns the value of the '<em><b>Collapsible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Collapsible</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Collapsible</em>' attribute.
	 * @see #setCollapsible(boolean)
	 * @see cevinedit.CevineditPackage#getCompartmentEReferenceCont_Collapsible()
	 * @model
	 * @generated
	 */
	boolean isCollapsible();

	/**
	 * Sets the value of the '{@link cevinedit.CompartmentEReferenceCont#isCollapsible <em>Collapsible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Collapsible</em>' attribute.
	 * @see #isCollapsible()
	 * @generated
	 */
	void setCollapsible(boolean value);

	/**
	 * Returns the value of the '<em><b>Layout</b></em>' attribute.
	 * The literals are from the enumeration {@link cevinedit.LayoutCompartment}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Layout</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layout</em>' attribute.
	 * @see cevinedit.LayoutCompartment
	 * @see #setLayout(LayoutCompartment)
	 * @see cevinedit.CevineditPackage#getCompartmentEReferenceCont_Layout()
	 * @model
	 * @generated
	 */
	LayoutCompartment getLayout();

	/**
	 * Sets the value of the '{@link cevinedit.CompartmentEReferenceCont#getLayout <em>Layout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Layout</em>' attribute.
	 * @see cevinedit.LayoutCompartment
	 * @see #getLayout()
	 * @generated
	 */
	void setLayout(LayoutCompartment value);

} // CompartmentEReferenceCont
