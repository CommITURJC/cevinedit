/**
 */
package cevinedit;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CE Vi NEdit Root</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link cevinedit.CEViNEditRoot#getDiagram <em>Diagram</em>}</li>
 *   <li>{@link cevinedit.CEViNEditRoot#getSourceMM <em>Source MM</em>}</li>
 * </ul>
 * </p>
 *
 * @see cevinedit.CevineditPackage#getCEViNEditRoot()
 * @model
 * @generated
 */
public interface CEViNEditRoot extends EObject {
	/**
	 * Returns the value of the '<em><b>Diagram</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Diagram</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Diagram</em>' containment reference.
	 * @see #setDiagram(Diagram)
	 * @see cevinedit.CevineditPackage#getCEViNEditRoot_Diagram()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Diagram getDiagram();

	/**
	 * Sets the value of the '{@link cevinedit.CEViNEditRoot#getDiagram <em>Diagram</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Diagram</em>' containment reference.
	 * @see #getDiagram()
	 * @generated
	 */
	void setDiagram(Diagram value);

	/**
	 * Returns the value of the '<em><b>Source MM</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source MM</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source MM</em>' attribute.
	 * @see #setSourceMM(String)
	 * @see cevinedit.CevineditPackage#getCEViNEditRoot_SourceMM()
	 * @model required="true"
	 * @generated
	 */
	String getSourceMM();

	/**
	 * Sets the value of the '{@link cevinedit.CEViNEditRoot#getSourceMM <em>Source MM</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source MM</em>' attribute.
	 * @see #getSourceMM()
	 * @generated
	 */
	void setSourceMM(String value);

} // CEViNEditRoot
